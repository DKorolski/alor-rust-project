//! Live Bybit orderbook scalping example inspired by the Python prototype.
//!
//! It connects to Bybit's public linear websocket feeds via `barter-data`,
//! maintains a local L2 order book, computes order-flow clusters and runs a
//! maker-only paper trading loop with cluster and time-stop exits.

use barter::logging::init_logging;
use barter_data::{
    event::{DataKind, MarketEvent},
    streams::builder::dynamic::indexed::init_indexed_multi_exchange_market_stream,
    streams::reconnect::Event as StreamEvent,
    subscription::SubKind,
};
use barter_instrument::{
    Underlying,
    asset::name::AssetNameExchange,
    exchange::ExchangeId,
    index::IndexedInstruments,
    instrument::{
        InstrumentIndex,
        kind::{InstrumentKind, perpetual::PerpetualContract},
        quote::InstrumentQuoteAsset,
    },
};
use chrono::{TimeZone, Utc};
use futures::StreamExt;
use rust_decimal::{
    Decimal,
    prelude::{FromPrimitive, ToPrimitive},
};
use rust_decimal_macros::dec;
use std::error::Error;
use std::fs::OpenOptions;
use std::io::{BufWriter, Write};
use tokio::signal;
use tracing::{info, warn};

const BYBIT_MARKET: &str = "BTCUSDT";
const TRADE_LOG_PATH: &str = "barter/examples/data/scalping_live_trades_new_2.csv";

#[derive(Debug, Clone, Copy)]
struct StrategyConfig {
    tick_size: Decimal,
    order_size: Decimal,
    fee_rate_maker: Decimal,
    fee_rate_taker: Decimal,
    broker_fee_abs: Decimal,
    tp_ticks: Decimal,
    entry_cluster_q: f64,
    exit_cluster_q: f64,
    entry_timeout_ms: u64,
    exit_timeout_ms: u64,
    time_stop_timeout_ms: u64,
    max_hold_ms: u64,
    min_history: usize,
    max_cluster_depth_entry: usize,
    max_cluster_depth_exit: usize,
    exit_cluster_start_ms: u64,
    exit_cluster_max_diff_ticks: Decimal,
}

impl Default for StrategyConfig {
    fn default() -> Self {
        Self {
            tick_size: dec!(0.1),
            order_size: dec!(1),
            fee_rate_maker: dec!(0.0),
            fee_rate_taker: dec!(0.000066),
            broker_fee_abs: dec!(1.0),
            tp_ticks: dec!(200),
            entry_cluster_q: 0.895,
            exit_cluster_q: 0.1,
            entry_timeout_ms: 800,
            exit_timeout_ms: 2_500,
            time_stop_timeout_ms: 800,
            max_hold_ms: 30_000,
            min_history: 50,
            max_cluster_depth_entry: 12,
            max_cluster_depth_exit: 12,
            exit_cluster_start_ms: 800,
            exit_cluster_max_diff_ticks: dec!(197),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Side {
    Buy,
    Sell,
}

impl Side {
    fn direction(self) -> i32 {
        match self {
            Side::Buy => 1,
            Side::Sell => -1,
        }
    }

    fn opposite(self) -> Self {
        match self {
            Side::Buy => Side::Sell,
            Side::Sell => Side::Buy,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct ClusterSideInfo {
    max_price: Decimal,
    max_size: Decimal,
    max_depth: usize,
    best_price: Decimal,
    best_size: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct ClusterInfo {
    bid: Option<ClusterSideInfo>,
    ask: Option<ClusterSideInfo>,
}

#[derive(Debug, Clone)]
struct TradeLog {
    entry_time: i64,
    exit_time: i64,
    direction: Side,
    entry_price: Decimal,
    exit_price: Decimal,
    gross_ticks: Decimal,
    net_ticks: Decimal,
    gross_ret: Decimal,
    net_ret: Decimal,
    reason: String,
    exit_liquidity: &'static str,
    tp_plain: Decimal,
    exit_from_cluster: bool,
    entry_fee: Decimal,
    exit_fee: Decimal,
    total_fee: Decimal,
    waited_ms_for_fill: u64,
    hold_ms: u64,
}

#[derive(Debug, Clone, Copy)]
struct PendingOrder {
    side: Side,
    price: Decimal,
    placed_ts: u64,
    queue_ahead: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct Position {
    direction: Side,
    entry_ts: u64,
    entry_price: Decimal,
    tp_plain: Decimal,
    entry_order_ts: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExitOrderKind {
    Cluster,
    TimeStop,
}

#[derive(Debug, Clone, Copy)]
struct ExitOrder {
    kind: ExitOrderKind,
    price: Decimal,
    placed_ts: u64,
    queue_ahead: Decimal,
}

#[derive(Debug, Clone)]
enum TradeState {
    Flat,
    WaitingEntry(PendingOrder),
    InPosition {
        position: Position,
        exit_order: Option<ExitOrder>,
    },
}

#[derive(Debug)]
struct ScalpingEngine {
    cfg: StrategyConfig,
    state: TradeState,
    bid_hist: Vec<f64>,
    ask_hist: Vec<f64>,
    bid_entry_thr: Option<f64>,
    ask_entry_thr: Option<f64>,
    bid_exit_thr: Option<f64>,
    ask_exit_thr: Option<f64>,
    last_trade_price: Option<Decimal>,
    last_mid: Option<Decimal>,
    trades: Vec<TradeLog>,
    trade_logger: TradeLogger,
}

impl ScalpingEngine {
    fn new(cfg: StrategyConfig) -> Self {
        let trade_logger = TradeLogger::new(TRADE_LOG_PATH);
        Self {
            cfg,
            state: TradeState::Flat,
            bid_hist: Vec::with_capacity(4096),
            ask_hist: Vec::with_capacity(4096),
            bid_entry_thr: None,
            ask_entry_thr: None,
            bid_exit_thr: None,
            ask_exit_thr: None,
            last_trade_price: None,
            last_mid: None,
            trades: Vec::new(),
            trade_logger,
        }
    }

    fn thresholds_ready(&self) -> bool {
        self.bid_entry_thr.is_some()
            && self.ask_entry_thr.is_some()
            && self.bid_exit_thr.is_some()
            && self.ask_exit_thr.is_some()
    }

    fn update_history(&mut self, cbv: Decimal, cav: Decimal) {
        if let Some(v) = cbv.to_f64() {
            if v > 0.0 {
                self.bid_hist.push(v);
            }
        }
        if let Some(v) = cav.to_f64() {
            if v > 0.0 {
                self.ask_hist.push(v);
            }
        }

        if self.bid_hist.len() >= self.cfg.min_history
            && self.ask_hist.len() >= self.cfg.min_history
        {
            self.bid_entry_thr = Some(quantile(&self.bid_hist, self.cfg.entry_cluster_q));
            self.ask_entry_thr = Some(quantile(&self.ask_hist, self.cfg.entry_cluster_q));
            self.bid_exit_thr = Some(quantile(&self.bid_hist, self.cfg.exit_cluster_q));
            self.ask_exit_thr = Some(quantile(&self.ask_hist, self.cfg.exit_cluster_q));
        }
    }

    fn on_orderbook(&mut self, ts: u64, clusters: ClusterInfo) {
        let best_bid = clusters.bid.map(|c| (c.best_price, c.best_size));
        let best_ask = clusters.ask.map(|c| (c.best_price, c.best_size));

        if let (Some((bbp, _)), Some((bap, _))) = (best_bid, best_ask) {
            self.last_mid = Some((bbp + bap) / dec!(2));
        }

        if let (Some(bid), Some(ask)) = (clusters.bid, clusters.ask) {
            self.update_history(bid.max_size, ask.max_size);
        }

        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);

        match state_snapshot {
            TradeState::Flat => {
                self.try_place_entry(ts, &clusters);
            }
            TradeState::WaitingEntry(pending) => {
                if ts.saturating_sub(pending.placed_ts) >= self.cfg.entry_timeout_ms {
                    info!(ts, price = %pending.price, "entry order timed out");
                    self.state = TradeState::Flat;
                } else {
                    self.state = TradeState::WaitingEntry(pending);
                }
            }
            TradeState::InPosition {
                mut position,
                mut exit_order,
            } => {
                self.evaluate_exit(
                    ts,
                    &mut position,
                    &mut exit_order,
                    &clusters,
                    best_bid,
                    best_ask,
                );
                self.state = TradeState::InPosition {
                    position,
                    exit_order,
                };
            }
        }
    }

    fn try_place_entry(&mut self, ts: u64, clusters: &ClusterInfo) {
        let (Some(bid), Some(ask)) = (clusters.bid, clusters.ask) else {
            return;
        };
        if !self.thresholds_ready() {
            return;
        }

        let bid_thr = self.bid_entry_thr.unwrap();
        let ask_thr = self.ask_entry_thr.unwrap();

        let bid_vol = bid.max_size.to_f64().unwrap_or(0.0);
        let ask_vol = ask.max_size.to_f64().unwrap_or(0.0);

        // ----- LONG -----
        if bid_vol >= bid_thr
            && bid.max_depth <= self.cfg.max_cluster_depth_entry
            && bid_vol > ask_vol
        {
            // 1 тик в сторону best_bid от цены кластера
            let candidate = bid.max_price + self.cfg.tick_size;
            // но не лучше best_bid (чтобы не стать тейкером)
            let order_price = candidate.min(bid.best_price);

            // очередь считаем только если реально встаём на best
            let queue_ahead = if order_price == bid.best_price {
                (bid.best_size - self.cfg.order_size).max(Decimal::ZERO)
            } else {
                Decimal::ZERO
            };

            self.state = TradeState::WaitingEntry(PendingOrder {
                side: Side::Buy,
                price: order_price,
                placed_ts: ts,
                queue_ahead,
            });
            info!(
                ts,
                price = %order_price,
                cluster_price = %bid.max_price,
                "pending long entry one tick before cluster toward best bid"
            );

        // ----- SHORT -----
        } else if ask_vol >= ask_thr
            && ask.max_depth <= self.cfg.max_cluster_depth_entry
            && ask_vol > bid_vol
        {
            // 1 тик в сторону best_ask от цены кластера
            let candidate = ask.max_price - self.cfg.tick_size;
            // но не ниже best_ask
            let order_price = candidate.max(ask.best_price);

            let queue_ahead = if order_price == ask.best_price {
                (ask.best_size - self.cfg.order_size).max(Decimal::ZERO)
            } else {
                Decimal::ZERO
            };

            self.state = TradeState::WaitingEntry(PendingOrder {
                side: Side::Sell,
                price: order_price,
                placed_ts: ts,
                queue_ahead,
            });
            info!(
                ts,
                price = %order_price,
                cluster_price = %ask.max_price,
                "pending short entry one tick before cluster toward best ask"
            );
        }
    }


    fn evaluate_exit(
        &mut self,
        ts: u64,
        position: &mut Position,
        exit_order: &mut Option<ExitOrder>,
        clusters: &ClusterInfo,
        best_bid: Option<(Decimal, Decimal)>,
        best_ask: Option<(Decimal, Decimal)>,
    ) {
        let elapsed = ts.saturating_sub(position.entry_ts);

        // Если время удержания позиции превышает max_hold_ms, производим выход
        if elapsed >= self.cfg.max_hold_ms {
            if exit_order.map(|o| o.kind) != Some(ExitOrderKind::TimeStop) {
                // Закрытие позиции по таймауту
                self.close_position_by_timeout(ts, position, exit_order);
            }
            return;
        }

        // Проверка для exit_order, если прошло больше времени, чем exit_timeout_ms
        if let Some(order) = exit_order.as_mut() {
            let timeout = match order.kind {
                ExitOrderKind::Cluster => self.cfg.exit_timeout_ms,
                ExitOrderKind::TimeStop => self.cfg.time_stop_timeout_ms,
            };
            if ts.saturating_sub(order.placed_ts) >= timeout {
                info!(ts, price = %order.price, "exit order expired");
                *exit_order = None;
            }
        }

        if elapsed < self.cfg.exit_cluster_start_ms {
            return;
        }

        if !self.thresholds_ready() {
            return;
        }

        match position.direction {
            Side::Buy => {
                if let Some(ask) = clusters.ask {
                    let ask_thr = self.ask_exit_thr.unwrap();
                    if ask.max_size.to_f64().unwrap_or(0.0) >= ask_thr
                        && ask.max_depth <= self.cfg.max_cluster_depth_exit
                    {
                        let candidate = ask.max_price - self.cfg.tick_size;
                        if price_diff_in_ticks(candidate, position.tp_plain, self.cfg.tick_size)
                            <= self.cfg.exit_cluster_max_diff_ticks
                        {
                            *exit_order = Some(ExitOrder {
                                kind: ExitOrderKind::Cluster,
                                price: candidate,
                                placed_ts: ts,
                                queue_ahead: Decimal::ZERO,
                            });
                            info!(ts, price = %candidate, "cluster exit (long)");
                        }
                    }
                }
            }
            Side::Sell => {
                if let Some(bid) = clusters.bid {
                    let bid_thr = self.bid_exit_thr.unwrap();
                    if bid.max_size.to_f64().unwrap_or(0.0) >= bid_thr
                        && bid.max_depth <= self.cfg.max_cluster_depth_exit
                    {
                        let candidate = bid.max_price + self.cfg.tick_size;
                        if price_diff_in_ticks(candidate, position.tp_plain, self.cfg.tick_size)
                            <= self.cfg.exit_cluster_max_diff_ticks
                        {
                            *exit_order = Some(ExitOrder {
                                kind: ExitOrderKind::Cluster,
                                price: candidate,
                                placed_ts: ts,
                                queue_ahead: Decimal::ZERO,
                            });
                            info!(ts, price = %candidate, "cluster exit (short)");
                        }
                    }
                }
            }
        }
    }

    fn close_position_by_timeout(
        &mut self,
        ts: u64,
        position: &Position,
        exit_order: &mut Option<ExitOrder>,
    ) {
        // Закрытие позиции по таймауту
        let exit_price = match position.direction {
            Side::Buy => {
                self.last_trade_price.unwrap_or(position.entry_price + self.cfg.tick_size)
            }
            Side::Sell => {
                self.last_trade_price.unwrap_or(position.entry_price - self.cfg.tick_size)
            }
        };

        // Создаем новый ExitOrder для выхода
        *exit_order = Some(ExitOrder {
            kind: ExitOrderKind::TimeStop,
            price: exit_price,
            placed_ts: ts,
            queue_ahead: Decimal::ZERO,
        });

        // Логирование и завершение позиции
        info!(ts, price = %exit_price, "time-stop exit placed");
        self.log_close(ts, position, exit_price, "time_stop_limit", false);
    }


    fn on_trade(&mut self, ts: u64, price: Decimal, size: Decimal) {
        self.last_trade_price = Some(price);

        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);

        match state_snapshot {
            TradeState::Flat => {}
            TradeState::WaitingEntry(mut pending) => {
                if self.try_fill_entry(&mut pending, price, size) {
                    let tp_plain = match pending.side {
                        Side::Buy => pending.price + self.cfg.tp_ticks * self.cfg.tick_size,
                        Side::Sell => pending.price - self.cfg.tp_ticks * self.cfg.tick_size,
                    };
                    let position = Position {
                        direction: pending.side,
                        entry_ts: ts,
                        entry_price: pending.price,
                        tp_plain,
                        entry_order_ts: pending.placed_ts,
                    };
                    info!(ts, price = %pending.price, "entry filled");
                    self.state = TradeState::InPosition {
                        position,
                        exit_order: None,
                    };
                } else {
                    self.state = TradeState::WaitingEntry(pending);
                }
            }
            TradeState::InPosition {
                position,
                mut exit_order,
            } => {
                if let Some(order) = exit_order.as_mut() {
                    if self.try_fill_exit(order, &position, price, size) {
                        let reason = match order.kind {
                            ExitOrderKind::Cluster => "cluster_exit",
                            ExitOrderKind::TimeStop => "time_stop_limit",
                        };
                        self.log_close(
                            ts,
                            &position,
                            order.price,
                            reason,
                            order.kind == ExitOrderKind::Cluster,
                        );
                        self.state = TradeState::Flat;
                        return;
                    }
                }
                self.state = TradeState::InPosition {
                    position,
                    exit_order,
                };
            }
        }
    }

    fn try_fill_entry(
        &mut self,
        order: &mut PendingOrder,
        trade_price: Decimal,
        trade_size: Decimal,
    ) -> bool {
        match order.side {
            Side::Buy => {
                if trade_price <= order.price {
                    order.queue_ahead -= trade_size;
                }
            }
            Side::Sell => {
                if trade_price >= order.price {
                    order.queue_ahead -= trade_size;
                }
            }
        }
        order.queue_ahead <= Decimal::ZERO
    }

    fn try_fill_exit(
        &mut self,
        order: &mut ExitOrder,
        position: &Position,
        trade_price: Decimal,
        trade_size: Decimal,
    ) -> bool {
        match position.direction {
            Side::Buy => {
                if trade_price >= order.price {
                    order.queue_ahead -= trade_size;
                }
            }
            Side::Sell => {
                if trade_price <= order.price {
                    order.queue_ahead -= trade_size;
                }
            }
        }
        order.queue_ahead <= Decimal::ZERO
    }

    fn log_close(
        &mut self,
        ts: u64,
        position: &Position,
        exit_price: Decimal,
        reason: &str,
        exit_from_cluster: bool,
    ) {
        let side = position.direction.direction();
        let pnl_px =
            Decimal::from(side) * (exit_price - position.entry_price) * self.cfg.order_size;

        let entry_fee = self.cfg.fee_rate_maker * position.entry_price * self.cfg.order_size
            + self.cfg.broker_fee_abs;
        let exit_fee =
            self.cfg.fee_rate_maker * exit_price * self.cfg.order_size + self.cfg.broker_fee_abs;
        let total_fee = entry_fee + exit_fee;

        let notional = position.entry_price * self.cfg.order_size;
        let gross_ret = pnl_px / notional;
        let net_ret = (pnl_px - total_fee) / notional;
        let rel_tick = self.cfg.tick_size / position.entry_price;
        let gross_ticks =
            Decimal::from(side) * (exit_price - position.entry_price) / self.cfg.tick_size;
        let net_ticks = net_ret / rel_tick;

        let waited_ms = ts.saturating_sub(position.entry_order_ts);
        let hold_ms = ts.saturating_sub(position.entry_ts);

        let log = TradeLog {
            entry_time: position.entry_ts as i64,
            exit_time: ts as i64,
            direction: position.direction,
            entry_price: position.entry_price,
            exit_price,
            gross_ticks,
            net_ticks,
            gross_ret,
            net_ret,
            reason: reason.to_string(),
            exit_liquidity: "maker",
            tp_plain: position.tp_plain,
            exit_from_cluster,
            entry_fee,
            exit_fee,
            total_fee,
            waited_ms_for_fill: waited_ms,
            hold_ms,
        };
        info!(ts, %exit_price, reason, "position closed");
        self.trade_logger.log_trade(&log);
        self.trades.push(log);
    }

    fn force_flatten(&mut self, ts: u64) {
        let position = match &self.state {
            TradeState::InPosition { position, .. } => *position,
            TradeState::WaitingEntry(_) | TradeState::Flat => return,
        };

        let exit_price = self
            .last_trade_price
            .or(self.last_mid)
            .unwrap_or(position.entry_price);
        self.log_close(ts, &position, exit_price, "eod_force", false);
        self.state = TradeState::Flat;
    }
}

fn price_diff_in_ticks(a: Decimal, b: Decimal, tick: Decimal) -> Decimal {
    let diff = if a > b { a - b } else { b - a };
    diff / tick
}

fn quantile(data: &[f64], q: f64) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    let mut sorted = data.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let idx = ((sorted.len() - 1) as f64 * q).round() as usize;
    sorted[idx]
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    init_logging();
    let cfg = StrategyConfig::default();
    info!(?cfg, "starting live paper scalper");

    let instruments = IndexedInstruments::new(vec![instrument_config()]);
    let mut market_stream = init_indexed_multi_exchange_market_stream(
        &instruments,
        &[SubKind::OrderBooksL2, SubKind::PublicTrades],
    )
    .await?;

    let mut engine = ScalpingEngine::new(cfg);
    let mut orderbook = barter_data::books::OrderBook::default();

    let mut stream = market_stream.fuse();
    let mut shutdown = signal::ctrl_c();
    tokio::pin!(shutdown);
    info!("listening for market data... press Ctrl+C to stop");

    loop {
        tokio::select! {
            _ = &mut shutdown => {
                warn!("shutdown signal received");
                break;
            }
            maybe_event = stream.next() => {
                let Some(stream_event) = maybe_event else { break; };
                match stream_event {
                    StreamEvent::Reconnecting(exchange) => warn!(%exchange, "market stream reconnecting"),
                    StreamEvent::Item(event) => handle_event(event, &mut orderbook, &mut engine),
                }
            }
        }
    }

    let now_ms = Utc::now().timestamp_millis() as u64;
    engine.force_flatten(now_ms);
    info!(count = engine.trades.len(), "session finished");
    Ok(())
}

fn handle_event(
    event: MarketEvent<InstrumentIndex, DataKind>,
    orderbook: &mut barter_data::books::OrderBook,
    engine: &mut ScalpingEngine,
) {
    match event.kind {
        DataKind::OrderBook(ob_event) => {
            orderbook.update(&ob_event);
            if let Some(clusters) = build_clusters(
                orderbook,
                engine.cfg.max_cluster_depth_entry,
                engine.cfg.max_cluster_depth_exit,
            ) {
                let ts = event.time_exchange.timestamp_millis() as u64;
                engine.on_orderbook(ts, clusters);
            }
        }
        DataKind::Trade(trade) => {
            let ts = event.time_exchange.timestamp_millis() as u64;
            let size = Decimal::from_f64(trade.amount).unwrap_or(Decimal::ZERO);
            let price = Decimal::from_f64(trade.price).unwrap_or(Decimal::ZERO);
            engine.on_trade(ts, price, size);
        }
        _ => {}
    }
}

#[derive(Debug)]
struct TradeLogger {
    writer: BufWriter<std::fs::File>,
    wrote_header: bool,
}

impl TradeLogger {
    fn new(path: &str) -> Self {
        let file = OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)   // <--- вместо append(true)
            .open(path)
            .expect("failed to open trade log file");
        let wrote_header = file.metadata().map(|m| m.len() > 0).unwrap_or(false);
        let mut logger = Self {
            writer: BufWriter::new(file),
            wrote_header,
        };
        logger.ensure_header();
        logger
    }

    fn ensure_header(&mut self) {
        if self.wrote_header {
            return;
        }
        let header = "entry_time,exit_time,direction,side,entry_price,exit_price,gross_ticks,net_ticks,gross_ret,net_ret,reason,exit_liquidity,tp_plain,exit_from_cluster,entry_fee,exit_fee,total_fee,waited_ms_for_fill,hold_ms";
        writeln!(self.writer, "{header}").expect("failed to write trade log header");
        self.wrote_header = true;
        self.writer.flush().ok();
    }

    fn log_trade(&mut self, trade: &TradeLog) {
        let entry_time = Utc
            .timestamp_millis_opt(trade.entry_time)
            .single()
            .unwrap_or_else(|| Utc::now())
            .to_rfc3339();
        let exit_time = Utc
            .timestamp_millis_opt(trade.exit_time)
            .single()
            .unwrap_or_else(|| Utc::now())
            .to_rfc3339();

        let direction = match trade.direction {
            Side::Buy => "long",
            Side::Sell => "short",
        };

        let exit_from_cluster = if trade.exit_from_cluster { "1" } else { "0" };

        let line = format!(
            "{entry_time},{exit_time},{direction},{side},{entry_price},{exit_price},{gross_ticks},{net_ticks},{gross_ret},{net_ret},{reason},{exit_liquidity},{tp_plain},{exit_from_cluster},{entry_fee},{exit_fee},{total_fee},{waited_ms},{hold_ms}",
            side = trade.direction.direction(),
            entry_price = trade.entry_price,
            exit_price = trade.exit_price,
            gross_ticks = trade.gross_ticks,
            net_ticks = trade.net_ticks,
            gross_ret = trade.gross_ret,
            net_ret = trade.net_ret,
            reason = trade.reason,
            exit_liquidity = trade.exit_liquidity,
            tp_plain = trade.tp_plain,
            entry_fee = trade.entry_fee,
            exit_fee = trade.exit_fee,
            total_fee = trade.total_fee,
            waited_ms = trade.waited_ms_for_fill,
            hold_ms = trade.hold_ms,
        );

        if let Err(err) = writeln!(self.writer, "{line}") {
            warn!(%err, "failed to write trade log row");
        }
        self.writer.flush().ok();
    }
}

fn build_clusters(
    book: &barter_data::books::OrderBook,
    entry_depth: usize,
    exit_depth: usize,
) -> Option<ClusterInfo> {
    let best_bid = book.bids().best()?.to_owned();
    let best_ask = book.asks().best()?.to_owned();

    let bid_cluster = compute_side_info(book.bids().levels(), entry_depth.max(exit_depth));
    let ask_cluster = compute_side_info(book.asks().levels(), entry_depth.max(exit_depth));

    Some(ClusterInfo {
        bid: bid_cluster.map(|mut c| {
            c.best_price = best_bid.price;
            c.best_size = best_bid.amount;
            c
        }),
        ask: ask_cluster.map(|mut c| {
            c.best_price = best_ask.price;
            c.best_size = best_ask.amount;
            c
        }),
    })
}

fn compute_side_info(
    levels: &[barter_data::books::Level],
    depth: usize,
) -> Option<ClusterSideInfo> {
    let Some(first) = levels.first() else {
        return None;
    };
    let mut max_level = *first;
    let mut max_depth = 0usize;
    for (idx, level) in levels.iter().take(depth).enumerate() {
        if level.amount > max_level.amount {
            max_level = *level;
            max_depth = idx;
        }
    }

    Some(ClusterSideInfo {
        max_price: max_level.price,
        max_size: max_level.amount,
        max_depth,
        best_price: first.price,
        best_size: first.amount,
    })
}

fn instrument_config() -> barter::system::config::InstrumentConfig {
    use barter::system::config::InstrumentConfig;

    InstrumentConfig {
        exchange: ExchangeId::BybitPerpetualsUsd,
        name_exchange: BYBIT_MARKET.into(),
        underlying: Underlying::new("btc", "usdt"),
        quote: InstrumentQuoteAsset::UnderlyingQuote,
        kind: InstrumentKind::Perpetual(PerpetualContract {
            contract_size: dec!(1),
            settlement_asset: AssetNameExchange::from("usdt"),
        }),
        spec: None,
    }
}