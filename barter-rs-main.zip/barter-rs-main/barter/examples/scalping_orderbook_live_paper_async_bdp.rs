use std::{fs::OpenOptions, io::Write};

use barter_data::{
    books::OrderBook,
    event::{DataKind, MarketEvent},
    streams::{
        builder::dynamic::indexed::init_indexed_multi_exchange_market_stream,
        reconnect::Event as StreamEvent,
    },
    subscription::SubKind,
};
use barter_instrument::{
    Side, Underlying,
    asset::name::AssetNameExchange,
    exchange::ExchangeId,
    index::IndexedInstruments,
    instrument::{
        InstrumentIndex,
        kind::{InstrumentKind, perpetual::PerpetualContract},
        quote::InstrumentQuoteAsset,
    },
};
use chrono::{DateTime, Utc};
use futures::StreamExt;
use rust_decimal::{Decimal, prelude::ToPrimitive};
use rust_decimal_macros::dec;
use tracing::{error, info, warn};

/// Simple live paper-trading scalper that mirrors the v8 backtest logic against
/// Bybit perpetual market data (orderbook L2 + public trades).
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    barter::logging::init_logging();

    let cfg = Config::default();
    let instruments = IndexedInstruments::new(vec![cfg.instrument_config()]);

    let mut stream = init_indexed_multi_exchange_market_stream(
        &instruments,
        &[SubKind::OrderBooksL2, SubKind::PublicTrades],
    )
    .await?;

    let mut strategy = Strategy::new(cfg)?;
    let mut orderbook = OrderBook::default();

    while let Some(event) = stream.next().await {
        match event {
            StreamEvent::Reconnecting(exchange) => warn!(%exchange, "stream reconnecting"),
            StreamEvent::Item(event) => strategy.on_event(&mut orderbook, event),
        }
    }

    Ok(())
}

struct Config {
    symbol: &'static str,
    tick_size: Decimal,
    order_size: Decimal,
    fee_rate_maker: Decimal,
    fee_rate_taker: Decimal,
    broker_fee_abs: Decimal,
    tp_ticks: i64,
    entry_cluster_q: f64,
    max_cluster_depth_entry: usize,
    exit_cluster_q: f64,
    max_cluster_depth_exit: usize,
    exit_cluster_start_ms: i64,
    exit_order_timeout_ms: i64,
    exit_cluster_max_diff_ticks: i64,
    max_hold_ms: i64,
    time_stop_order_timeout_ms: i64,
    entry_order_timeout_ms: i64,
    history_min: usize,
    trade_log_path: &'static str,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            symbol: "BTCUSDT",
            tick_size: dec!(0.1),
            order_size: dec!(1.0),
            fee_rate_maker: Decimal::ZERO,
            fee_rate_taker: dec!(0.0066) / dec!(100),
            broker_fee_abs: dec!(1.0),
            tp_ticks: 200,
            entry_cluster_q: 0.895,
            max_cluster_depth_entry: 12,
            exit_cluster_q: 0.1,
            max_cluster_depth_exit: 12,
            exit_cluster_start_ms: 800,
            exit_order_timeout_ms: 2_500,
            exit_cluster_max_diff_ticks: 197,
            max_hold_ms: 15_000,
            time_stop_order_timeout_ms: 800,
            entry_order_timeout_ms: 800,
            history_min: 50,
            trade_log_path: "barter/examples/data/scalping_live_trades_async.csv",
        }
    }
}

impl Config {
    fn instrument_config(&self) -> barter::system::config::InstrumentConfig {
        barter::system::config::InstrumentConfig {
            exchange: ExchangeId::BybitPerpetualsUsd,
            name_exchange: self.symbol.into(),
            underlying: Underlying::new("btc", "usdt"),
            quote: InstrumentQuoteAsset::UnderlyingQuote,
            kind: InstrumentKind::Perpetual(PerpetualContract {
                contract_size: dec!(1),
                settlement_asset: AssetNameExchange::from("usdt"),
            }),
            spec: None,
        }
    }
}

struct Strategy {
    cfg: Config,
    cluster_history_bid: Vec<f64>,
    cluster_history_ask: Vec<f64>,
    exit_history_bid: Vec<f64>,
    exit_history_ask: Vec<f64>,
    entry_order: Option<PendingOrder>,
    exit_order: Option<PendingOrder>,
    position: Option<Position>,
    trade_log: TradeLogger,
}

impl Strategy {
    fn new(cfg: Config) -> Result<Self, std::io::Error> {
        let mut trade_log = TradeLogger::new(cfg.trade_log_path)?;
        trade_log.write_header()?;

        Ok(Self {
            cfg,
            cluster_history_bid: Vec::new(),
            cluster_history_ask: Vec::new(),
            exit_history_bid: Vec::new(),
            exit_history_ask: Vec::new(),
            entry_order: None,
            exit_order: None,
            position: None,
            trade_log,
        })
    }

    fn on_event(
        &mut self,
        orderbook: &mut OrderBook,
        event: MarketEvent<InstrumentIndex, DataKind>,
    ) {
        match event.kind {
            DataKind::OrderBook(orderbook_event) => {
                orderbook.update(&orderbook_event);
                self.on_orderbook(event.time_exchange, orderbook);
            }
            DataKind::Trade(trade) => {
                self.on_trade(event.time_exchange, trade);
            }
            _ => {}
        }
    }

    fn on_orderbook(&mut self, now: DateTime<Utc>, orderbook: &OrderBook) {
        let ts = now.timestamp_millis();
        let bid_strength = cluster_strength(orderbook.bids(), self.cfg.max_cluster_depth_entry);
        let ask_strength = cluster_strength(orderbook.asks(), self.cfg.max_cluster_depth_entry);

        if bid_strength > 0.0 {
            self.cluster_history_bid.push(bid_strength);
        }
        if ask_strength > 0.0 {
            self.cluster_history_ask.push(ask_strength);
        }

        if let Some(mut pos) = self.position.take() {
            let exit_bid = cluster_strength(orderbook.bids(), self.cfg.max_cluster_depth_exit);
            let exit_ask = cluster_strength(orderbook.asks(), self.cfg.max_cluster_depth_exit);
            if exit_bid > 0.0 {
                self.exit_history_bid.push(exit_bid);
            }
            if exit_ask > 0.0 {
                self.exit_history_ask.push(exit_ask);
            }
            self.handle_exit_logic(orderbook, ts, &mut pos, exit_bid, exit_ask);
            self.position = Some(pos);
        } else {
            self.check_entry_signal(orderbook, ts, bid_strength, ask_strength);
        }

        self.prune_entry_if_timeout(ts);
        self.prune_exit_if_timeout(ts);
    }

    fn on_trade(
        &mut self,
        now: DateTime<Utc>,
        trade: barter_data::subscription::trade::PublicTrade,
    ) {
        let ts = now.timestamp_millis();

        if let Some(order) = self.entry_order.take() {
            if order.fills_entry(trade.price) {
                let position = Position::enter(order.side, order.price, ts, &self.cfg);
                info!(?position, "entry filled");
                self.position = Some(position);
                self.exit_order = None;
                return;
            } else {
                self.entry_order = Some(order);
            }
        }

        if let Some(position) = self.position.as_ref() {
            if let Some(order) = self.exit_order.take() {
                if order.fills_exit(trade.price, position.side) {
                    let exit_price = order.price;
                    let hold_ms = ts - position.entry_time_ms;
                    let pnl = TradePnl::from_exit(position, exit_price, hold_ms, &self.cfg);
                    if let Err(err) = self.trade_log.write(&pnl) {
                        error!(%err, "failed to write trade log");
                    }
                    info!(?pnl, "position closed");
                    self.position = None;
                    return;
                } else {
                    self.exit_order = Some(order);
                }
            }
        }
    }

    fn check_entry_signal(
        &mut self,
        orderbook: &OrderBook,
        ts: i64,
        bid_strength: f64,
        ask_strength: f64,
    ) {
        if self.entry_order.is_some() {
            return;
        }

        if self
            .cluster_history_bid
            .len()
            .min(self.cluster_history_ask.len())
            < self.cfg.history_min
        {
            return;
        }

        let bid_thr = quantile(&self.cluster_history_bid, self.cfg.entry_cluster_q);
        let ask_thr = quantile(&self.cluster_history_ask, self.cfg.entry_cluster_q);

        let best_bid = match orderbook.bids().best() {
            Some(level) => level.price,
            None => return,
        };
        let best_ask = match orderbook.asks().best() {
            Some(level) => level.price,
            None => return,
        };

        if bid_strength >= bid_thr && bid_strength > ask_strength {
            let order_price = best_bid - self.cfg.tick_size;
            self.entry_order = Some(PendingOrder::new(
                Side::Buy,
                order_price,
                ts,
                self.cfg.entry_order_timeout_ms,
            ));
            info!(price = %order_price, "place long entry one tick inside cluster bid");
        } else if ask_strength >= ask_thr && ask_strength > bid_strength {
            let order_price = best_ask + self.cfg.tick_size;
            self.entry_order = Some(PendingOrder::new(
                Side::Sell,
                order_price,
                ts,
                self.cfg.entry_order_timeout_ms,
            ));
            info!(price = %order_price, "place short entry one tick inside cluster ask");
        }
    }

    fn handle_exit_logic(
        &mut self,
        orderbook: &OrderBook,
        ts: i64,
        position: &mut Position,
        exit_bid_strength: f64,
        exit_ask_strength: f64,
    ) {
        let elapsed = ts - position.entry_time_ms;

        if elapsed >= self.cfg.max_hold_ms && position.state != PositionState::TimeStop {
            position.state = PositionState::TimeStop;
            self.exit_order = None;
        }

        match position.state {
            PositionState::Normal => {
                if elapsed < self.cfg.exit_cluster_start_ms {
                    return;
                }

                let (strength, history, best_price, side) = match position.side {
                    Side::Buy => (
                        exit_ask_strength,
                        &self.exit_history_ask,
                        orderbook.asks().best().map(|l| l.price),
                        Side::Sell,
                    ),
                    Side::Sell => (
                        exit_bid_strength,
                        &self.exit_history_bid,
                        orderbook.bids().best().map(|l| l.price),
                        Side::Buy,
                    ),
                };

                if history.len() < self.cfg.history_min {
                    return;
                }

                let threshold = quantile(history, self.cfg.exit_cluster_q);
                if strength < threshold {
                    return;
                }

                let Some(best_price) = best_price else {
                    return;
                };
                let diff_ticks = ((best_price - position.tp_plain).abs() / self.cfg.tick_size)
                    .to_i64()
                    .unwrap_or(i64::MAX);
                if diff_ticks > self.cfg.exit_cluster_max_diff_ticks {
                    return;
                }

                let exit_price = match position.side {
                    Side::Buy => (best_price - self.cfg.tick_size).min(best_price),
                    Side::Sell => (best_price + self.cfg.tick_size).max(best_price),
                };
                self.exit_order = Some(PendingOrder::new(
                    side,
                    exit_price,
                    ts,
                    self.cfg.exit_order_timeout_ms,
                ));
            }
            PositionState::TimeStop => {
                let exit_price = match position.side {
                    Side::Buy => orderbook.bids().best().map(|l| l.price),
                    Side::Sell => orderbook.asks().best().map(|l| l.price),
                };
                if let Some(exit_price) = exit_price {
                    self.exit_order = Some(PendingOrder::new(
                        position.side.opposite(),
                        exit_price,
                        ts,
                        self.cfg.time_stop_order_timeout_ms,
                    ));
                }
            }
        }
    }

    fn prune_entry_if_timeout(&mut self, ts: i64) {
        if let Some(order) = &self.entry_order {
            if ts - order.created_ms > order.ttl_ms {
                self.entry_order = None;
                info!("entry order expired");
            }
        }
    }

    fn prune_exit_if_timeout(&mut self, ts: i64) {
        if let Some(order) = &self.exit_order {
            if ts - order.created_ms > order.ttl_ms {
                self.exit_order = None;
            }
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct PendingOrder {
    side: Side,
    price: Decimal,
    created_ms: i64,
    ttl_ms: i64,
}

impl PendingOrder {
    fn new(side: Side, price: Decimal, created_ms: i64, ttl_ms: i64) -> Self {
        Self {
            side,
            price,
            created_ms,
            ttl_ms,
        }
    }

    fn fills_entry(&self, trade_price: f64) -> bool {
        let price = Decimal::from_f64_retain(trade_price).unwrap_or_default();
        match self.side {
            Side::Buy => price <= self.price,
            Side::Sell => price >= self.price,
        }
    }

    fn fills_exit(&self, trade_price: f64, position_side: Side) -> bool {
        let price = Decimal::from_f64_retain(trade_price).unwrap_or_default();
        match position_side {
            Side::Buy => price >= self.price,
            Side::Sell => price <= self.price,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PositionState {
    Normal,
    TimeStop,
}

#[derive(Clone, Copy, Debug)]
struct Position {
    side: Side,
    entry_price: Decimal,
    entry_time_ms: i64,
    tp_plain: Decimal,
    state: PositionState,
}

impl Position {
    fn enter(side: Side, entry_price: Decimal, entry_time_ms: i64, cfg: &Config) -> Self {
        let tp_plain = match side {
            Side::Buy => entry_price + cfg.tick_size * Decimal::from(cfg.tp_ticks),
            Side::Sell => entry_price - cfg.tick_size * Decimal::from(cfg.tp_ticks),
        };
        Self {
            side,
            entry_price,
            entry_time_ms,
            tp_plain,
            state: PositionState::Normal,
        }
    }
}

#[derive(Debug)]
struct TradePnl {
    entry_time_ms: i64,
    exit_time_ms: i64,
    direction: Side,
    entry_price: Decimal,
    exit_price: Decimal,
    gross_ticks: Decimal,
    net_ticks: Decimal,
    gross_ret: Decimal,
    net_ret: Decimal,
    reason: &'static str,
    tp_plain: Decimal,
    exit_from_cluster: bool,
    entry_fee: Decimal,
    exit_fee: Decimal,
    total_fee: Decimal,
    hold_ms: i64,
}

impl TradePnl {
    fn from_exit(pos: &Position, exit_price: Decimal, hold_ms: i64, cfg: &Config) -> Self {
        let direction = pos.side;
        let ticks = (exit_price - pos.entry_price) / cfg.tick_size;
        let gross_ticks = match direction {
            Side::Buy => ticks,
            Side::Sell => -ticks,
        };
        let entry_fee = pos.entry_price * cfg.fee_rate_maker + cfg.broker_fee_abs;
        let exit_fee = exit_price * cfg.fee_rate_maker + cfg.broker_fee_abs;
        let total_fee = entry_fee + exit_fee;
        let net_ticks = gross_ticks - total_fee / cfg.tick_size;
        let gross_ret = match direction {
            Side::Buy => (exit_price - pos.entry_price) / pos.entry_price,
            Side::Sell => (pos.entry_price - exit_price) / pos.entry_price,
        };
        let net_ret = gross_ret - total_fee / pos.entry_price;
        Self {
            entry_time_ms: pos.entry_time_ms,
            exit_time_ms: pos.entry_time_ms + hold_ms,
            direction,
            entry_price: pos.entry_price,
            exit_price,
            gross_ticks,
            net_ticks,
            gross_ret,
            net_ret,
            reason: match pos.state {
                PositionState::Normal => "cluster_exit",
                PositionState::TimeStop => "time_stop_limit",
            },
            tp_plain: pos.tp_plain,
            exit_from_cluster: pos.state == PositionState::Normal,
            entry_fee,
            exit_fee,
            total_fee,
            hold_ms,
        }
    }
}

struct TradeLogger {
    writer: std::io::BufWriter<std::fs::File>,
}

impl TradeLogger {
    fn new(path: &str) -> Result<Self, std::io::Error> {
        let file = OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)
            .open(path)?;
        Ok(Self {
            writer: std::io::BufWriter::new(file),
        })
    }

    fn write_header(&mut self) -> Result<(), std::io::Error> {
        writeln!(
            self.writer,
            "entry_time,exit_time,direction,side,entry_price,exit_price,gross_ticks,net_ticks,gross_ret,net_ret,reason,exit_liquidity,tp_plain,exit_from_cluster,entry_fee,exit_fee,total_fee,hold_ms"
        )?;

        self.writer.flush()
    }

    fn write(&mut self, pnl: &TradePnl) -> Result<(), std::io::Error> {
        writeln!(
            self.writer,
            "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}",
            pnl.entry_time_ms,
            pnl.exit_time_ms,
            direction_label(pnl.direction),
            side_sign(pnl.direction),
            pnl.entry_price,
            pnl.exit_price,
            pnl.gross_ticks,
            pnl.net_ticks,
            pnl.gross_ret,
            pnl.net_ret,
            pnl.reason,
            "maker",
            pnl.tp_plain,
            pnl.exit_from_cluster,
            pnl.entry_fee,
            pnl.exit_fee,
            pnl.total_fee,
            pnl.hold_ms,
        )?;

        self.writer.flush()
    }
}

fn cluster_strength<Side>(side: &barter_data::books::OrderBookSide<Side>, depth: usize) -> f64
where
    Side: std::fmt::Display + std::fmt::Debug,
{
    side.levels()
        .iter()
        .take(depth)
        .map(|level| level.amount.to_f64().unwrap_or(0.0))
        .sum()
}

fn quantile(data: &[f64], q: f64) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    let mut sorted = data.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let idx = ((sorted.len() as f64 - 1.0) * q).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn direction_label(side: Side) -> &'static str {
    match side {
        Side::Buy => "long",
        Side::Sell => "short",
    }
}

fn side_sign(side: Side) -> i8 {
    match side {
        Side::Buy => 1,
        Side::Sell => -1,
    }
}

trait Opposite {
    fn opposite(self) -> Self;
}

impl Opposite for Side {
    fn opposite(self) -> Self {
        match self {
            Side::Buy => Side::Sell,
            Side::Sell => Side::Buy,
        }
    }
}

trait ToI64 {
    fn to_i64(self) -> Option<i64>;
}

impl ToI64 for Decimal {
    fn to_i64(self) -> Option<i64> {
        self.to_i128().map(|v| v as i64)
    }
}