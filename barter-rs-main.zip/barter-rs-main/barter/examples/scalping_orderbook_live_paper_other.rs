//! Live paper-trading example for the orderbook-driven scalping strategy.
//!
//! This adapts the offline back-test example to stream Bybit public
//! L2 orderbook and trade data via WebSocket, run the same "v8" style
//! cluster-based entry/exit logic, and record paper trades to CSV.

use barter::logging::init_logging;
use futures_util::{SinkExt, StreamExt};
use rust_decimal::{
    Decimal,
    prelude::{FromPrimitive, ToPrimitive},
};
use rust_decimal_macros::dec;
use serde::{Deserialize, Deserializer};
use serde_json::json;
use std::{
    cmp::Ordering,
    error::Error,
    fs,
    path::Path,
    time::Duration,
};
use tokio::{
    signal,
    sync::mpsc::{self, UnboundedSender},
    time::sleep,
};
use tokio_tungstenite::{connect_async, tungstenite::protocol::Message};
use tracing::{info, warn};

const MIN_HISTORY: usize = 50;
const ORDER_SIZE: Decimal = dec!(1);

#[derive(Debug, Clone)]
struct LiveConfig {
    endpoint: String,
    symbol: String,
    depth: usize,
    output_path: String,
    reconnect_backoff_secs: Vec<u64>,
}

impl Default for LiveConfig {
    fn default() -> Self {
        Self {
            endpoint: "wss://stream.bybit.com/v5/public/linear".to_string(),
            symbol: "BTCUSDT".to_string(),
            depth: 200,
            output_path: "barter/examples/data/scalping_live_trades_1.csv".to_string(),
            reconnect_backoff_secs: vec![3, 5, 10],
        }
    }
}

/// Core configuration for the strategy. Values mirror the Python reference
/// with small rounding allowances for decimal arithmetic.
#[derive(Debug, Clone, Copy)]
struct StrategyConfig {
    maker_fee: Decimal,
    taker_fee: Decimal,
    broker_fee_abs: Decimal,
    tp_ticks: Decimal,
    entry_cluster_q: f64,
    exit_cluster_q: f64,
    exit_cluster_start_ms: u64,
    exit_cluster_max_diff_ticks: Decimal,
    max_hold_ms: u64,
    time_stop_reprice_ms: u64,
    tick_size: Decimal,
    entry_timeout_ms: u64,
    exit_order_timeout_ms: u64,
    max_cluster_depth_entry: usize,
    max_cluster_depth_exit: usize,
}

impl Default for StrategyConfig {
    fn default() -> Self {
        Self {
            maker_fee: dec!(0.0),
            taker_fee: dec!(0.0003),
            broker_fee_abs: dec!(1.0),
            tp_ticks: dec!(200),
            entry_cluster_q: 0.895,
            exit_cluster_q: 0.3,
            exit_cluster_start_ms: 800,
            exit_cluster_max_diff_ticks: dec!(197),
            max_hold_ms: 20_000,
            time_stop_reprice_ms: 800,
            tick_size: dec!(0.1),
            entry_timeout_ms: 2500,
            exit_order_timeout_ms: 2_500,
            max_cluster_depth_entry: 12,
            max_cluster_depth_exit: 12,
        }
    }
}

#[derive(Debug, Deserialize, Clone, Copy, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
enum Side {
    #[serde(alias = "Buy", alias = "BUY")]
    Buy,
    #[serde(alias = "Sell", alias = "SELL")]
    Sell,
}

impl Side {
    fn direction(self) -> i32 {
        match self {
            Side::Buy => 1,
            Side::Sell => -1,
        }
    }

    fn opposite(self) -> Self {
        match self {
            Side::Buy => Side::Sell,
            Side::Sell => Side::Buy,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Level {
    price: Decimal,
    size: Decimal,
}

#[derive(Debug, Clone)]
struct OrderbookMessage {
    ts: u64,
    data: OrderbookData,
}

#[derive(Debug, Default, Clone)]
struct OrderbookData {
    b: Vec<Level>,
    a: Vec<Level>,
}

#[derive(Debug, Clone)]
enum MarketEvent {
    Orderbook(OrderbookMessage),
    Trade(TradeEvent),
}

#[derive(Debug, Clone)]
struct TradeEvent {
    ts: u64,
    side: Side,
    price: Decimal,
    size: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct PendingOrder {
    side: Side,
    price: Decimal,
    placed_ts: u64,
    queue_ahead: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct Position {
    direction: Side,
    entry_time: u64,
    entry_price: Decimal,
    tp_plain: Decimal,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExitOrderKind {
    Cluster,
    TimeStop,
}

#[derive(Debug, Clone, Copy)]
struct ExitOrder {
    kind: ExitOrderKind,
    price: Decimal,
    placed_ts: u64,
    queue_ahead: Decimal,
}

#[derive(Debug, Clone)]
enum TradeState {
    Flat,
    WaitingEntry(PendingOrder),
    InPosition {
        position: Position,
        exit_order: Option<ExitOrder>,
    },
}

#[derive(Debug, Clone, Copy)]
struct ClusterSideInfo {
    max_price: Decimal,
    max_size: Decimal,
    max_depth: usize,
    best_price: Decimal,
    best_size: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct ClusterInfo {
    bid: Option<ClusterSideInfo>,
    ask: Option<ClusterSideInfo>,
}

#[derive(Debug, Clone, Copy)]
enum ExitReason {
    Cluster,
    TimeStopLimit,
    EodForce,
}

#[derive(Debug, Clone)]
struct TradeLog {
    entry_time: u64,
    exit_time: u64,
    direction: Side,
    entry_price: Decimal,
    exit_price: Decimal,
    gross_ticks: Decimal,
    net_ticks: Decimal,
    gross_ret: Decimal,
    net_ret: Decimal,
    reason: ExitReason,
    exit_liquidity: &'static str,
    tp_plain: Decimal,
    exit_from_cluster: bool,
    entry_fee: Decimal,
    exit_fee: Decimal,
    total_fee: Decimal,
    hold_ms: u64,
}

#[derive(Debug, Deserialize)]
struct WsEnvelope {
    #[serde(rename = "topic")]
    topic: Option<String>,
    #[serde(rename = "type")]
    kind: Option<String>,
    ts: Option<u64>,
    data: Option<serde_json::Value>,
    op: Option<String>,
    success: Option<bool>,
}

#[derive(Debug, Default, Deserialize, Clone)]
struct BybitOrderbookData {
    #[serde(default, deserialize_with = "deserialize_levels")]
    b: Vec<Level>,
    #[serde(default, deserialize_with = "deserialize_levels")]
    a: Vec<Level>,
}

#[derive(Debug, Deserialize, Clone)]
struct BybitTrade {
    #[serde(rename = "T")]
    ts: u64,
    #[serde(rename = "S")]
    side: Side,
    #[serde(rename = "p", deserialize_with = "decimal_from_string")]
    price: Decimal,
    #[serde(rename = "v", deserialize_with = "decimal_from_string")]
    size: Decimal,
}

impl BybitTrade {
    fn into_event(self, fallback_ts: Option<u64>) -> TradeEvent {
        TradeEvent {
            ts: fallback_ts.unwrap_or(self.ts),
            side: self.side,
            price: self.price,
            size: self.size,
        }
    }
}

#[derive(Debug, Clone)]
struct LiveOrderbookState {
    bids: Vec<Level>,
    asks: Vec<Level>,
    depth: usize,
}

impl LiveOrderbookState {
    fn new(depth: usize) -> Self {
        Self {
            bids: Vec::with_capacity(depth),
            asks: Vec::with_capacity(depth),
            depth,
        }
    }

    fn apply_snapshot(&mut self, data: &BybitOrderbookData) {
        self.bids = Self::sorted(data.b.clone(), true, self.depth);
        self.asks = Self::sorted(data.a.clone(), false, self.depth);
    }

    fn apply_delta(&mut self, data: &BybitOrderbookData) {
        for level in &data.b {
            upsert_level(&mut self.bids, *level, true, self.depth);
        }
        for level in &data.a {
            upsert_level(&mut self.asks, *level, false, self.depth);
        }
    }

    fn to_message(&self, ts: u64) -> OrderbookMessage {
        OrderbookMessage {
            ts,
            data: OrderbookData {
                b: self.bids.clone(),
                a: self.asks.clone(),
            },
        }
    }

    fn sorted(mut levels: Vec<Level>, is_bid: bool, depth: usize) -> Vec<Level> {
        if is_bid {
            levels.sort_by(|a, b| b.price.cmp(&a.price));
        } else {
            levels.sort_by(|a, b| a.price.cmp(&b.price));
        }
        levels.truncate(depth);
        levels
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    init_logging();

    let config = StrategyConfig::default();
    let live_cfg = LiveConfig::default();
    info!(?config, ?live_cfg, "starting live scalping paper trader");

    let (tx, mut rx) = mpsc::unbounded_channel();
    tokio::spawn(run_bybit_stream(live_cfg.clone(), tx));

    let mut ctx = StrategyContext::new(config, live_cfg.output_path.clone());

    let mut shutdown = signal::ctrl_c();
    tokio::pin!(shutdown);
    loop {
        tokio::select! {
            Some(event) = rx.recv() => {
                ctx.on_event(event);
            }
            _ = &mut shutdown => {
                warn!("ctrl-c received, closing state");
                break;
            }
        }
    }

    ctx.finalize();
    write_results(&ctx.trades, &live_cfg.output_path)?;
    info!(trades = ctx.trades.len(), "live session finished");
    Ok(())
}

async fn run_bybit_stream(config: LiveConfig, tx: UnboundedSender<MarketEvent>) {
    let mut backoff = config.reconnect_backoff_secs.iter().copied().cycle();

    loop {
        if let Err(err) = connect_once(&config, tx.clone()).await {
            warn!(%err, "bybit stream ended with error");
        }

        let delay = backoff.next().unwrap_or(5);
        sleep(Duration::from_secs(delay)).await;
    }
}

async fn connect_once(
    config: &LiveConfig,
    tx: UnboundedSender<MarketEvent>,
) -> Result<(), Box<dyn Error>> {
    let url = url::Url::parse(&config.endpoint)?;
    info!(%url, "connecting to bybit public websocket");

    let (stream, _) = connect_async(url).await?;
    info!("websocket connected, subscribing");

    let (mut ws_tx, mut ws_rx) = stream.split();
    let topics = vec![
        format!("orderbook.{}.{}", config.depth, config.symbol),
        format!("publicTrade.{}", config.symbol),
    ];
    let subscribe = json!({
        "op": "subscribe",
        "args": topics,
    });
    ws_tx
        .send(Message::Text(subscribe.to_string().into()))
        .await?;

    let mut orderbook = LiveOrderbookState::new(config.depth);

    while let Some(msg) = ws_rx.next().await {
        let msg = msg?;
        if msg.is_close() {
            warn!("websocket close frame received");
            break;
        }
        if msg.is_ping() {
            ws_tx.send(Message::Pong(Vec::new().into())).await?;
            continue;
        }
        if !msg.is_text() {
            continue;
        }

        let text = msg.into_text()?;
        let envelope: WsEnvelope = match serde_json::from_str(&text) {
            Ok(env) => env,
            Err(err) => {
                warn!(%err, %text, "failed to parse ws message");
                continue;
            }
        };

        if envelope.op.as_deref() == Some("ping") {
            ws_tx
                .send(Message::Text(json!({"op": "pong"}).to_string().into()))
                .await?;
            continue;
        }

        if envelope.success == Some(true) {
            continue;
        }

        let Some(topic) = envelope.topic else {
            continue;
        };
        if topic.starts_with("orderbook") {
            let Some(raw) = envelope.data else { continue };
            let Ok(data) = serde_json::from_value::<BybitOrderbookData>(raw) else {
                continue;
            };

            match envelope.kind.as_deref() {
                Some("snapshot") => orderbook.apply_snapshot(&data),
                Some("delta") => orderbook.apply_delta(&data),
                _ => {}
            }

            if let Some(ts) = envelope.ts {
                if tx
                    .send(MarketEvent::Orderbook(orderbook.to_message(ts)))
                    .is_err()
                {
                    break;
                }
            }
        } else if topic.starts_with("publicTrade") {
            let Some(raw) = envelope.data else { continue };
            let Ok(trades) = serde_json::from_value::<Vec<BybitTrade>>(raw) else {
                continue;
            };

            for trade in trades {
                let event = trade.into_event(envelope.ts);
                if tx.send(MarketEvent::Trade(event)).is_err() {
                    return Ok(());
                }
            }
        }
    }

    Ok(())
}

struct StrategyContext {
    config: StrategyConfig,
    output_path: String,
    bid_history_entry: Vec<f64>,
    ask_history_entry: Vec<f64>,
    bid_history_exit: Vec<f64>,
    ask_history_exit: Vec<f64>,
    state: TradeState,
    last_best_bid: Option<Level>,
    last_best_ask: Option<Level>,
    last_trade_price: Option<Decimal>,
    last_ts: Option<u64>,
    trades: Vec<TradeLog>,
}

impl StrategyContext {
    fn new(config: StrategyConfig, output_path: String) -> Self {
        Self {
            config,
            output_path,
            bid_history_entry: Vec::with_capacity(2048),
            ask_history_entry: Vec::with_capacity(2048),
            bid_history_exit: Vec::with_capacity(2048),
            ask_history_exit: Vec::with_capacity(2048),
            state: TradeState::Flat,
            last_best_bid: None,
            last_best_ask: None,
            last_trade_price: None,
            last_ts: None,
            trades: Vec::new(),
        }
    }

    fn on_event(&mut self, event: MarketEvent) {
        match event {
            MarketEvent::Orderbook(ob) => {
                self.last_ts = Some(ob.ts);
                self.on_orderbook(ob);
            }
            MarketEvent::Trade(trade) => {
                self.last_ts = Some(trade.ts);
                self.on_trade(trade)
            }
        }
    }

    fn on_orderbook(&mut self, ob: OrderbookMessage) {
        let entry_clusters = compute_cluster_info(&ob.data, self.config.max_cluster_depth_entry);
        let exit_clusters = compute_cluster_info(&ob.data, self.config.max_cluster_depth_exit);

        if let Some(bid) = entry_clusters.bid {
            self.last_best_bid = Some(Level {
                price: bid.best_price,
                size: bid.best_size,
            });
            self.bid_history_entry.push(dec_to_f64(bid.max_size));
        }

        if let Some(ask) = entry_clusters.ask {
            self.last_best_ask = Some(Level {
                price: ask.best_price,
                size: ask.best_size,
            });
            self.ask_history_entry.push(dec_to_f64(ask.max_size));
        }

        if let Some(bid) = exit_clusters.bid {
            self.bid_history_exit.push(dec_to_f64(bid.max_size));
        }

        if let Some(ask) = exit_clusters.ask {
            self.ask_history_exit.push(dec_to_f64(ask.max_size));
        }

        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);

        match state_snapshot {
            TradeState::Flat => {
                self.evaluate_entry(ob.ts, &entry_clusters);
            }
            TradeState::WaitingEntry(pending) => {
                let waited = ob.ts.saturating_sub(pending.placed_ts);
                if waited >= self.config.entry_timeout_ms {
                    info!(ts = ob.ts, "entry order timed out");
                    self.state = TradeState::Flat;
                } else {
                    self.state = TradeState::WaitingEntry(pending);
                }
            }
            TradeState::InPosition {
                mut position,
                mut exit_order,
            } => {
                self.evaluate_exit(ob.ts, &mut position, &mut exit_order, &exit_clusters);
                self.state = TradeState::InPosition {
                    position,
                    exit_order,
                };
            }
        }
    }

    fn on_trade(&mut self, trade: TradeEvent) {
        self.last_trade_price = Some(trade.price);

        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);

        match state_snapshot {
            TradeState::Flat => {}
            TradeState::WaitingEntry(mut pending) => {
                if self.try_fill_entry(&mut pending, &trade) {
                    let entry_price = pending.price;
                    let tp_plain = match pending.side {
                        Side::Buy => entry_price + self.config.tp_ticks * self.config.tick_size,
                        Side::Sell => entry_price - self.config.tp_ticks * self.config.tick_size,
                    };

                    let position = Position {
                        direction: pending.side,
                        entry_time: trade.ts,
                        entry_price,
                        tp_plain,
                    };

                    info!(ts = trade.ts, %entry_price, ?pending.side, "entry filled");
                    self.state = TradeState::InPosition {
                        position,
                        exit_order: None,
                    };
                } else {
                    self.state = TradeState::WaitingEntry(pending);
                }
            }
            TradeState::InPosition {
                position,
                mut exit_order,
            } => {
                if let Some(order) = exit_order.as_mut() {
                    if self.try_fill_exit(order, &position, &trade) {
                        let reason = match order.kind {
                            ExitOrderKind::Cluster => ExitReason::Cluster,
                            ExitOrderKind::TimeStop => ExitReason::TimeStopLimit,
                        };
                        self.log_close(
                            &position,
                            trade.ts,
                            order.price,
                            reason,
                            order.kind == ExitOrderKind::Cluster,
                        );
                        self.state = TradeState::Flat;
                        return;
                    }
                }

                self.state = TradeState::InPosition {
                    position,
                    exit_order,
                };
            }
        }
    }

    fn evaluate_entry(&mut self, ts: u64, clusters: &ClusterInfo) {
        let (Some(bid), Some(ask)) = (clusters.bid, clusters.ask) else {
            return;
        };

        if self.bid_history_entry.len() < MIN_HISTORY || self.ask_history_entry.len() < MIN_HISTORY
        {
            return;
        }

        let bid_thr = quantile(&self.bid_history_entry, self.config.entry_cluster_q);
        let ask_thr = quantile(&self.ask_history_entry, self.config.entry_cluster_q);

        if dec_to_f64(bid.max_size) >= bid_thr
            && bid.max_depth <= self.config.max_cluster_depth_entry
        {
            let queue_ahead = (bid.best_size - ORDER_SIZE).max(Decimal::ZERO);
            self.state = TradeState::WaitingEntry(PendingOrder {
                side: Side::Buy,
                price: bid.best_price,
                placed_ts: ts,
                queue_ahead,
            });
            info!(ts, price = %bid.best_price, "pending long entry");
        } else if dec_to_f64(ask.max_size) >= ask_thr
            && ask.max_depth <= self.config.max_cluster_depth_entry
        {
            let queue_ahead = (ask.best_size - ORDER_SIZE).max(Decimal::ZERO);
            self.state = TradeState::WaitingEntry(PendingOrder {
                side: Side::Sell,
                price: ask.best_price,
                placed_ts: ts,
                queue_ahead,
            });
            info!(ts, price = %ask.best_price, "pending short entry");
        }
    }

    fn evaluate_exit(
        &mut self,
        ts: u64,
        position: &mut Position,
        exit_order: &mut Option<ExitOrder>,
        clusters: &ClusterInfo,
    ) {
        let Some(best_bid) = self.last_best_bid else {
            return;
        };
        let Some(best_ask) = self.last_best_ask else {
            return;
        };

        if let Some(order) = exit_order.as_mut() {
            match order.kind {
                ExitOrderKind::Cluster => {
                    if ts.saturating_sub(order.placed_ts) >= self.config.exit_order_timeout_ms {
                        info!(ts, price = %order.price, "cluster exit expired");
                        *exit_order = None;
                    }
                }
                ExitOrderKind::TimeStop => {
                    if ts.saturating_sub(order.placed_ts) >= self.config.time_stop_reprice_ms {
                        let (price, queue) = match position.direction {
                            Side::Buy => (
                                best_ask.price,
                                (best_ask.size - ORDER_SIZE).max(Decimal::ZERO),
                            ),
                            Side::Sell => (
                                best_bid.price,
                                (best_bid.size - ORDER_SIZE).max(Decimal::ZERO),
                            ),
                        };
                        *order = ExitOrder {
                            kind: ExitOrderKind::TimeStop,
                            price,
                            placed_ts: ts,
                            queue_ahead: queue,
                        };
                        info!(ts, %price, "repriced time-stop exit");
                    }
                }
            }
        }

        let elapsed = ts.saturating_sub(position.entry_time);

        if elapsed >= self.config.max_hold_ms {
            if exit_order.map(|o| o.kind) != Some(ExitOrderKind::TimeStop) {
                let (price, queue) = match position.direction {
                    Side::Buy => (
                        best_bid.price,
                        (best_bid.size - ORDER_SIZE).max(Decimal::ZERO),
                    ),
                    Side::Sell => (
                        best_ask.price,
                        (best_ask.size - ORDER_SIZE).max(Decimal::ZERO),
                    ),
                };
                *exit_order = Some(ExitOrder {
                    kind: ExitOrderKind::TimeStop,
                    price,
                    placed_ts: ts,
                    queue_ahead: queue,
                });
                info!(ts, %price, "time-stop activated");
            }
            return;
        }

        let eligible = matches!(
            exit_order,
            None | Some(ExitOrder {
                kind: ExitOrderKind::TimeStop,
                ..
            })
        );
        if !eligible || elapsed < self.config.exit_cluster_start_ms {
            return;
        }

        match position.direction {
            Side::Buy => self.try_place_exit(ts, position, exit_order, clusters.ask, best_ask),
            Side::Sell => self.try_place_exit(ts, position, exit_order, clusters.bid, best_bid),
        }
    }

    fn try_place_exit(
        &mut self,
        ts: u64,
        position: &Position,
        exit_order: &mut Option<ExitOrder>,
        side_info: Option<ClusterSideInfo>,
        best: Level,
    ) {
        let Some(cluster) = side_info else {
            return;
        };

        let history = match position.direction {
            Side::Buy => &self.ask_history_exit,
            Side::Sell => &self.bid_history_exit,
        };

        if history.len() < MIN_HISTORY {
            return;
        }

        let thr = quantile(history, self.config.exit_cluster_q);
        if dec_to_f64(cluster.max_size) < thr {
            return;
        }

        let diff_ticks =
            price_diff_in_ticks(cluster.max_price, position.tp_plain, self.config.tick_size);
        if diff_ticks > self.config.exit_cluster_max_diff_ticks {
            return;
        }

        let exit_price = match position.direction {
            Side::Buy => (cluster.max_price - self.config.tick_size).min(best.price),
            Side::Sell => (cluster.max_price + self.config.tick_size).max(best.price),
        };
        let queue = (cluster.max_size - ORDER_SIZE).max(Decimal::ZERO);

        *exit_order = Some(ExitOrder {
            kind: ExitOrderKind::Cluster,
            price: exit_price,
            placed_ts: ts,
            queue_ahead: queue,
        });
        info!(ts, %exit_price, "placed cluster exit");
    }

    fn try_fill_entry(&self, pending: &mut PendingOrder, trade: &TradeEvent) -> bool {
        match pending.side {
            Side::Buy => {
                if trade.side == Side::Sell && trade.price <= pending.price {
                    pending.queue_ahead = Decimal::ZERO;
                    return true;
                }
            }
            Side::Sell => {
                if trade.side == Side::Buy && trade.price >= pending.price {
                    pending.queue_ahead = Decimal::ZERO;
                    return true;
                }
            }
        }

        false
    }

    fn try_fill_exit(
        &self,
        order: &mut ExitOrder,
        position: &Position,
        trade: &TradeEvent,
    ) -> bool {
        match position.direction {
            Side::Buy => {
                if trade.side == Side::Buy && trade.price >= order.price {
                    order.queue_ahead = Decimal::ZERO;
                    return true;
                }
            }
            Side::Sell => {
                if trade.side == Side::Sell && trade.price <= order.price {
                    order.queue_ahead = Decimal::ZERO;
                    return true;
                }
            }
        }

        false
    }

    fn log_close(
        &mut self,
        position: &Position,
        exit_time: u64,
        exit_price: Decimal,
        reason: ExitReason,
        exit_from_cluster: bool,
    ) {
        let side = position.direction.direction();
        let gross_ticks = (exit_price - position.entry_price) / self.config.tick_size
            * Decimal::from_i32(side).unwrap();

        let entry_fee = self.exchange_fee(position.entry_price, self.config.maker_fee);
        let exit_fee = match reason {
            ExitReason::TimeStopLimit | ExitReason::Cluster => {
                self.exchange_fee(exit_price, self.config.maker_fee)
            }
            ExitReason::EodForce => self.exchange_fee(exit_price, self.config.taker_fee),
        };
        let total_fee = entry_fee + exit_fee;

        let gross_ret = (exit_price - position.entry_price) / position.entry_price
            * Decimal::from_i32(side).unwrap();
        let net_ticks = gross_ticks - total_fee / self.config.tick_size;
        let net_ret = gross_ret - total_fee / position.entry_price;

        self.trades.push(TradeLog {
            entry_time: position.entry_time,
            exit_time,
            direction: position.direction,
            entry_price: position.entry_price,
            exit_price,
            gross_ticks,
            net_ticks,
            gross_ret,
            net_ret,
            reason,
            exit_liquidity: "maker",
            tp_plain: position.tp_plain,
            exit_from_cluster,
            entry_fee,
            exit_fee,
            total_fee,
            hold_ms: exit_time.saturating_sub(position.entry_time),
        });

        if let Err(err) = write_results(&self.trades, &self.output_path) {
            warn!(%err, "failed to write trades CSV");
        }

        info!(
            entry_time = position.entry_time,
            exit_time,
            %exit_price,
            %net_ticks,
            trades = self.trades.len(),
            "position closed"
        );
    }

    fn force_close(&mut self, ts: u64) {
        let position = match &self.state {
            TradeState::InPosition { position, .. } => *position,
            TradeState::WaitingEntry(_) => {
                self.state = TradeState::Flat;
                return;
            }
            TradeState::Flat => return,
        };

        let exit_price = if let Some(price) = self.last_trade_price {
            price
        } else if let (Some(bid), Some(ask)) = (self.last_best_bid, self.last_best_ask) {
            (bid.price + ask.price) / dec!(2)
        } else {
            position.entry_price
        };

        self.log_close(&position, ts, exit_price, ExitReason::EodForce, false);

        self.state = TradeState::Flat;
    }

    fn finalize(&mut self) {
        if !matches!(self.state, TradeState::Flat) {
            warn!("forcing end-of-day exit");
            let ts = self.last_ts.unwrap_or(0);
            self.force_close(ts);
        }
    }

    fn exchange_fee(&self, price: Decimal, rate: Decimal) -> Decimal {
        (price * rate * ORDER_SIZE) + self.config.broker_fee_abs
    }
}

fn upsert_level(levels: &mut Vec<Level>, update: Level, is_bid: bool, depth: usize) {
    if update.size == Decimal::ZERO {
        levels.retain(|lvl| lvl.price != update.price);
    } else if let Some(lvl) = levels.iter_mut().find(|lvl| lvl.price == update.price) {
        lvl.size = update.size;
    } else {
        levels.push(update);
    }

    if is_bid {
        levels.sort_by(|a, b| b.price.cmp(&a.price));
    } else {
        levels.sort_by(|a, b| a.price.cmp(&b.price));
    }
    levels.truncate(depth);
}

fn price_diff_in_ticks(a: Decimal, b: Decimal, tick: Decimal) -> Decimal {
    let diff = if a > b { a - b } else { b - a };
    diff / tick
}

fn dec_to_f64(value: Decimal) -> f64 {
    value.to_f64().unwrap_or(0.0)
}

fn compute_cluster_info(data: &OrderbookData, depth: usize) -> ClusterInfo {
    let bid = compute_side_info(&data.b, depth);
    let ask = compute_side_info(&data.a, depth);
    ClusterInfo { bid, ask }
}

fn compute_side_info(levels: &[Level], depth: usize) -> Option<ClusterSideInfo> {
    let best = levels.first()?;
    let mut max = *best;
    let mut max_depth = 0;

    for (idx, level) in levels.iter().take(depth).enumerate() {
        if level.size > max.size {
            max = *level;
            max_depth = idx;
        }
    }

    Some(ClusterSideInfo {
        max_price: max.price,
        max_size: max.size,
        max_depth,
        best_price: best.price,
        best_size: best.size,
    })
}

fn quantile(data: &[f64], q: f64) -> f64 {
    if data.is_empty() {
        return 0.0;
    }

    let mut sorted = data.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let idx = ((sorted.len() - 1) as f64 * q).round() as usize;
    sorted[idx]
}

fn write_results(trades: &[TradeLog], path: &str) -> Result<(), Box<dyn Error>> {
    let path = Path::new(path);
    if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
        fs::create_dir_all(parent)?;
    }

    let mut writer = csv::Writer::from_path(path)?;

    writer.write_record([
        "entry_time",
        "exit_time",
        "direction",
        "side",
        "entry_price",
        "exit_price",
        "gross_ticks",
        "net_ticks",
        "gross_ret",
        "net_ret",
        "reason",
        "exit_liquidity",
        "tp_plain",
        "exit_from_cluster",
        "entry_fee",
        "exit_fee",
        "total_fee",
        "hold_ms",
    ])?;

    for trade in trades {
        writer.write_record([
            trade.entry_time.to_string(),
            trade.exit_time.to_string(),
            format!("{:?}", trade.direction).to_lowercase(),
            trade.direction.direction().to_string(),
            trade.entry_price.to_string(),
            trade.exit_price.to_string(),
            trade.gross_ticks.to_string(),
            trade.net_ticks.to_string(),
            trade.gross_ret.to_string(),
            trade.net_ret.to_string(),
            format!("{:?}", trade.reason).to_lowercase(),
            trade.exit_liquidity.to_string(),
            trade.tp_plain.to_string(),
            trade.exit_from_cluster.to_string(),
            trade.entry_fee.to_string(),
            trade.exit_fee.to_string(),
            trade.total_fee.to_string(),
            trade.hold_ms.to_string(),
        ])?;
    }

    writer.flush()?;
    Ok(())
}

fn deserialize_levels<'de, D>(deserializer: D) -> Result<Vec<Level>, D::Error>
where
    D: Deserializer<'de>,
{
    let raw: Vec<Vec<String>> = Vec::deserialize(deserializer)?;
    let mut out = Vec::with_capacity(raw.len());

    for level in raw {
        if level.len() < 2 {
            continue;
        }
        let price = Decimal::from_str_exact(&level[0]).map_err(serde::de::Error::custom)?;
        let size = Decimal::from_str_exact(&level[1]).map_err(serde::de::Error::custom)?;
        out.push(Level { price, size });
    }

    Ok(out)
}

fn decimal_from_string<'de, D>(deserializer: D) -> Result<Decimal, D::Error>
where
    D: Deserializer<'de>,
{
    let s = String::deserialize(deserializer)?;
    Decimal::from_str_exact(&s).map_err(serde::de::Error::custom)
}