//! Live paper-trading variant of the scalping orderbook strategy ("v8" style).
//! Connects to Bybit public WebSocket feeds for OrderBook L2 depth and public
//! trades, drives the same cluster-based signal logic as the offline back-test,
//! and writes filled trades to CSV in near real-time.
//!
//! Run with optional JSON config path argument:
//!
//! ```bash
//! cargo run -p barter --example scalping_orderbook_live_paper \
//!   -- barter/examples/config/scalping_live_paper.json
//! ```
//!
//! If no path is provided the defaults baked into `AppConfig::default()` are
//! used (BTCUSDT perpetual on Bybit, depth=50 channel).

use barter::logging::init_logging;
use barter_data::{
    books::OrderBook, event::DataKind,
    streams::builder::dynamic::indexed::init_indexed_multi_exchange_market_stream,
    streams::consumer::MarketStreamEvent, subscription::SubKind,
};
use barter_instrument::{Side, index::IndexedInstruments, instrument::InstrumentIndex};
use futures::StreamExt;
use rust_decimal::{
    Decimal,
    prelude::{FromPrimitive, ToPrimitive},
};
use rust_decimal_macros::dec;
use serde::{Deserialize, Serialize};
use std::{
    cmp::Ordering,
    collections::HashMap,
    error::Error,
    fs::File,
    path::Path,
    time::{Duration, Instant},
};
use tracing::{info, warn};

const DEFAULT_APP_CONFIG: &str = "barter/examples/config/scalping_live_paper.json";
const DEFAULT_SYSTEM_CONFIG: &str = "barter/examples/config/system_config_bybit_perpetual.json";
const DEFAULT_OUTPUT_PATH: &str = "barter/examples/data/scalping_live_trades.csv";

#[derive(Debug, Deserialize, Clone)]
struct AppConfig {
    #[serde(default = "default_system_config_path")]
    system_config_path: String,
    #[serde(default = "default_output_path")]
    output_csv: String,
    #[serde(default = "default_runtime_secs")]
    runtime_secs: u64,
    #[serde(default = "default_min_history")]
    min_history: usize,
    #[serde(default)]
    strategy: StrategyConfig,
}

fn default_system_config_path() -> String {
    DEFAULT_SYSTEM_CONFIG.to_string()
}

fn default_output_path() -> String {
    DEFAULT_OUTPUT_PATH.to_string()
}

fn default_runtime_secs() -> u64 {
    60
}

fn default_min_history() -> usize {
    50
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            system_config_path: default_system_config_path(),
            output_csv: default_output_path(),
            runtime_secs: default_runtime_secs(),
            min_history: default_min_history(),
            strategy: StrategyConfig::default(),
        }
    }
}

/// Core configuration for the live strategy.
#[derive(Debug, Clone, Deserialize, Copy)]
struct StrategyConfig {
    tick_size: Decimal,
    order_size: Decimal,
    fee_rate_maker: Decimal,
    fee_rate_taker: Decimal,
    broker_fee_abs: Decimal,
    tp_ticks: Decimal,
    entry_cluster_q: f64,
    max_cluster_depth_entry: usize,
    exit_cluster_q: f64,
    max_cluster_depth_exit: usize,
    exit_cluster_start_ms: u64,
    exit_order_timeout_ms: u64,
    exit_cluster_max_diff_ticks: Decimal,
    max_hold_ms: u64,
    time_stop_order_timeout_ms: u64,
    entry_order_timeout_ms: u64,
}

impl Default for StrategyConfig {
    fn default() -> Self {
        Self {
            tick_size: dec!(0.1),
            order_size: dec!(1),
            fee_rate_maker: dec!(0.0),
            fee_rate_taker: dec!(0.000066),
            broker_fee_abs: dec!(1.0),
            tp_ticks: dec!(200),
            entry_cluster_q: 0.895,
            max_cluster_depth_entry: 12,
            exit_cluster_q: 0.3,
            max_cluster_depth_exit: 12,
            exit_cluster_start_ms: 800,
            exit_order_timeout_ms: 2500,
            exit_cluster_max_diff_ticks: dec!(197),
            max_hold_ms: 25_000,
            time_stop_order_timeout_ms: 800,
            entry_order_timeout_ms: 2500,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Level {
    price: Decimal,
    amount: Decimal,
}

#[derive(Debug, Clone)]
enum MarketUpdate {
    OrderBook {
        ts: u64,
        book: OrderBook,
    },
    Trade {
        ts: u64,
        side: Side,
        price: Decimal,
        size: Decimal,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExitOrderKind {
    Cluster,
    TimeStop,
}

#[derive(Debug, Clone, Copy)]
struct PendingOrder {
    side: Side,
    price: Decimal,
    placed_ts: u64,
    queue_ahead: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct Position {
    direction: Side,
    entry_time: u64,
    entry_price: Decimal,
    tp_plain: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct ExitOrder {
    kind: ExitOrderKind,
    price: Decimal,
    placed_ts: u64,
    queue_ahead: Decimal,
}

#[derive(Debug, Clone)]
enum TradeState {
    Flat,
    WaitingEntry(PendingOrder),
    InPosition {
        position: Position,
        exit_order: Option<ExitOrder>,
    },
}

#[derive(Debug, Clone, Copy, Serialize)]
enum ExitReason {
    Cluster,
    TimeStopLimit,
}

#[derive(Debug, Clone, Serialize)]
struct TradeLog {
    entry_time: u64,
    exit_time: u64,
    direction: Side,
    entry_price: Decimal,
    exit_price: Decimal,
    gross_ticks: Decimal,
    net_ticks: Decimal,
    gross_ret: Decimal,
    net_ret: Decimal,
    reason: ExitReason,
    exit_liquidity: &'static str,
    tp_plain: Decimal,
    exit_from_cluster: bool,
    entry_fee: Decimal,
    exit_fee: Decimal,
    total_fee: Decimal,
    hold_ms: u64,
}

struct LivePaperTrader {
    config: StrategyConfig,
    min_history: usize,
    bid_history_entry: Vec<f64>,
    ask_history_entry: Vec<f64>,
    bid_history_exit: Vec<f64>,
    ask_history_exit: Vec<f64>,
    state: TradeState,
    last_best_bid: Option<Level>,
    last_best_ask: Option<Level>,
    last_trade_price: Option<Decimal>,
    last_ts: Option<u64>,
    trades: Vec<TradeLog>,
    writer: csv::Writer<File>,
}

impl LivePaperTrader {
    fn direction_factor(side: Side) -> Decimal {
        match side {
            Side::Buy => Decimal::ONE,
            Side::Sell => Decimal::NEGATIVE_ONE,
        }
    }

    fn new(config: StrategyConfig, min_history: usize, writer: csv::Writer<File>) -> Self {
        Self {
            config,
            min_history,
            bid_history_entry: Vec::with_capacity(4096),
            ask_history_entry: Vec::with_capacity(4096),
            bid_history_exit: Vec::with_capacity(4096),
            ask_history_exit: Vec::with_capacity(4096),
            state: TradeState::Flat,
            last_best_bid: None,
            last_best_ask: None,
            last_trade_price: None,
            last_ts: None,
            trades: Vec::new(),
            writer,
        }
    }

    fn on_update(&mut self, update: MarketUpdate) {
        match update {
            MarketUpdate::OrderBook { ts, book } => {
                self.last_ts = Some(ts);
                let snapshot = book.snapshot(
                    self.config
                        .max_cluster_depth_entry
                        .max(self.config.max_cluster_depth_exit),
                );
                self.process_orderbook(ts, snapshot);
            }
            MarketUpdate::Trade {
                ts,
                side,
                price,
                size: _,
            } => {
                self.last_ts = Some(ts);
                self.last_trade_price = Some(price);
                self.process_trade(ts, side, price);
            }
        }
    }

    fn process_orderbook(&mut self, ts: u64, book: OrderBook) {
        let entry_clusters = compute_cluster_info(&book, self.config.max_cluster_depth_entry);
        let exit_clusters = compute_cluster_info(&book, self.config.max_cluster_depth_exit);

        if let Some(bid) = entry_clusters.bid {
            self.last_best_bid = Some(Level {
                price: bid.best_price,
                amount: bid.best_size,
            });
            if let Some(size) = bid.max_size.to_f64() {
                self.bid_history_entry.push(size);
            }
        }
        if let Some(ask) = entry_clusters.ask {
            self.last_best_ask = Some(Level {
                price: ask.best_price,
                amount: ask.best_size,
            });
            if let Some(size) = ask.max_size.to_f64() {
                self.ask_history_entry.push(size);
            }
        }
        if let Some(bid) = exit_clusters.bid {
            if let Some(size) = bid.max_size.to_f64() {
                self.bid_history_exit.push(size);
            }
        }
        if let Some(ask) = exit_clusters.ask {
            if let Some(size) = ask.max_size.to_f64() {
                self.ask_history_exit.push(size);
            }
        }

        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);
        match state_snapshot {
            TradeState::Flat => self.evaluate_entry(ts, &entry_clusters),
            TradeState::WaitingEntry(pending) => {
                let waited = ts.saturating_sub(pending.placed_ts);
                if waited >= self.config.entry_order_timeout_ms {
                    info!(ts, "entry order timed out");
                    self.state = TradeState::Flat;
                } else {
                    self.state = TradeState::WaitingEntry(pending);
                }
            }
            TradeState::InPosition {
                mut position,
                mut exit_order,
            } => {
                self.evaluate_exit(ts, &mut position, &mut exit_order, &exit_clusters);
                self.state = TradeState::InPosition {
                    position,
                    exit_order,
                };
            }
        }
    }

    fn process_trade(&mut self, ts: u64, side: Side, price: Decimal) {
        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);
        match state_snapshot {
            TradeState::Flat => {}
            TradeState::WaitingEntry(mut pending) => {
                if self.try_fill_entry(&mut pending, side, price) {
                    let entry_price = pending.price;
                    let tp_plain = match pending.side {
                        Side::Buy => entry_price + self.config.tp_ticks * self.config.tick_size,
                        Side::Sell => entry_price - self.config.tp_ticks * self.config.tick_size,
                    };
                    let position = Position {
                        direction: pending.side,
                        entry_time: ts,
                        entry_price,
                        tp_plain,
                    };
                    info!(ts, %entry_price, ?pending.side, "entry filled");
                    self.state = TradeState::InPosition {
                        position,
                        exit_order: None,
                    };
                } else {
                    self.state = TradeState::WaitingEntry(pending);
                }
            }
            TradeState::InPosition {
                position,
                mut exit_order,
            } => {
                if let Some(order) = exit_order.as_mut() {
                    if self.try_fill_exit(order, &position, side, price) {
                        let reason = match order.kind {
                            ExitOrderKind::Cluster => ExitReason::Cluster,
                            ExitOrderKind::TimeStop => ExitReason::TimeStopLimit,
                        };
                        self.log_close(
                            &position,
                            ts,
                            order.price,
                            reason,
                            order.kind == ExitOrderKind::Cluster,
                        );
                        self.state = TradeState::Flat;
                        return;
                    }
                }
                self.state = TradeState::InPosition {
                    position,
                    exit_order,
                };
            }
        }
    }

    fn evaluate_entry(&mut self, ts: u64, clusters: &ClusterInfo) {
        let (Some(bid), Some(ask)) = (clusters.bid, clusters.ask) else {
            self.state = TradeState::Flat;
            return;
        };

        if self.bid_history_entry.len() < self.min_history
            || self.ask_history_entry.len() < self.min_history
        {
            self.state = TradeState::Flat;
            return;
        }

        let bid_thr = quantile(&self.bid_history_entry, self.config.entry_cluster_q);
        let ask_thr = quantile(&self.ask_history_entry, self.config.entry_cluster_q);

        if bid.max_size.to_f64().map_or(false, |size| size >= bid_thr)
            && bid.max_depth <= self.config.max_cluster_depth_entry
        {
            let queue_ahead = (bid.best_size - self.config.order_size).max(Decimal::ZERO);
            self.state = TradeState::WaitingEntry(PendingOrder {
                side: Side::Buy,
                price: bid.best_price,
                placed_ts: ts,
                queue_ahead,
            });
            info!(ts, price = %bid.best_price, "pending long entry");
        } else if ask.max_size.to_f64().map_or(false, |size| size >= ask_thr)
            && ask.max_depth <= self.config.max_cluster_depth_entry
        {
            let queue_ahead = (ask.best_size - self.config.order_size).max(Decimal::ZERO);
            self.state = TradeState::WaitingEntry(PendingOrder {
                side: Side::Sell,
                price: ask.best_price,
                placed_ts: ts,
                queue_ahead,
            });
            info!(ts, price = %ask.best_price, "pending short entry");
        } else {
            self.state = TradeState::Flat;
        }
    }

    fn evaluate_exit(
        &mut self,
        ts: u64,
        position: &mut Position,
        exit_order: &mut Option<ExitOrder>,
        clusters: &ClusterInfo,
    ) {
        let Some(best_bid) = self.last_best_bid else {
            return;
        };
        let Some(best_ask) = self.last_best_ask else {
            return;
        };

        if let Some(order) = exit_order.as_mut() {
            match order.kind {
                ExitOrderKind::Cluster => {
                    if ts.saturating_sub(order.placed_ts) >= self.config.exit_order_timeout_ms {
                        info!(ts, price = %order.price, "cluster exit expired");
                        *exit_order = None;
                    }
                }
                ExitOrderKind::TimeStop => {
                    if ts.saturating_sub(order.placed_ts) >= self.config.time_stop_order_timeout_ms
                    {
                        let (price, queue) = match position.direction {
                            Side::Buy => (
                                best_ask.price,
                                (best_ask.amount - self.config.order_size).max(Decimal::ZERO),
                            ),
                            Side::Sell => (
                                best_bid.price,
                                (best_bid.amount - self.config.order_size).max(Decimal::ZERO),
                            ),
                        };
                        *order = ExitOrder {
                            kind: ExitOrderKind::TimeStop,
                            price,
                            placed_ts: ts,
                            queue_ahead: queue,
                        };
                        info!(ts, %price, "repriced time-stop exit");
                    }
                }
            }
        }

        let elapsed = ts.saturating_sub(position.entry_time);
        if elapsed >= self.config.max_hold_ms {
            if exit_order.map(|o| o.kind) != Some(ExitOrderKind::TimeStop) {
                let (price, queue) = match position.direction {
                    Side::Buy => (
                        best_ask.price,
                        (best_ask.amount - self.config.order_size).max(Decimal::ZERO),
                    ),
                    Side::Sell => (
                        best_bid.price,
                        (best_bid.amount - self.config.order_size).max(Decimal::ZERO),
                    ),
                };
                *exit_order = Some(ExitOrder {
                    kind: ExitOrderKind::TimeStop,
                    price,
                    placed_ts: ts,
                    queue_ahead: queue,
                });
                info!(ts, price = %price, "entered time-stop mode");
            }
            return;
        }

        if elapsed < self.config.exit_cluster_start_ms {
            return;
        }

        let (Some(bid), Some(ask)) = (clusters.bid, clusters.ask) else {
            return;
        };
        if position.direction == Side::Buy {
            if let Some(thr) = quantile_if_ready(
                &self.ask_history_exit,
                self.config.exit_cluster_q,
                self.min_history,
            ) {
                if ask.max_size.to_f64().map_or(false, |size| size >= thr) {
                    let diff_ticks = price_diff_in_ticks(
                        ask.max_price,
                        position.tp_plain,
                        self.config.tick_size,
                    );
                    if diff_ticks <= self.config.exit_cluster_max_diff_ticks {
                        let exit_price =
                            (ask.max_price - self.config.tick_size).min(best_ask.price);
                        let queue = (ask.best_size - self.config.order_size).max(Decimal::ZERO);
                        *exit_order = Some(ExitOrder {
                            kind: ExitOrderKind::Cluster,
                            price: exit_price,
                            placed_ts: ts,
                            queue_ahead: queue,
                        });
                        info!(ts, price = %exit_price, "cluster exit (long)");
                    }
                }
            }
        } else if let Some(thr) = quantile_if_ready(
            &self.bid_history_exit,
            self.config.exit_cluster_q,
            self.min_history,
        ) {
            if bid.max_size.to_f64().map_or(false, |size| size >= thr) {
                let diff_ticks =
                    price_diff_in_ticks(bid.max_price, position.tp_plain, self.config.tick_size);
                if diff_ticks <= self.config.exit_cluster_max_diff_ticks {
                    let exit_price = (bid.max_price + self.config.tick_size).max(best_bid.price);
                    let queue = (bid.best_size - self.config.order_size).max(Decimal::ZERO);
                    *exit_order = Some(ExitOrder {
                        kind: ExitOrderKind::Cluster,
                        price: exit_price,
                        placed_ts: ts,
                        queue_ahead: queue,
                    });
                    info!(ts, price = %exit_price, "cluster exit (short)");
                }
            }
        }
    }

    fn try_fill_entry(
        &self,
        pending: &mut PendingOrder,
        trade_side: Side,
        trade_price: Decimal,
    ) -> bool {
        match pending.side {
            Side::Buy if trade_side == Side::Sell && trade_price <= pending.price => true,
            Side::Sell if trade_side == Side::Buy && trade_price >= pending.price => true,
            _ => false,
        }
    }

    fn try_fill_exit(
        &self,
        order: &mut ExitOrder,
        position: &Position,
        trade_side: Side,
        trade_price: Decimal,
    ) -> bool {
        match (position.direction, trade_side) {
            (Side::Buy, Side::Buy) if trade_price >= order.price => true,
            (Side::Sell, Side::Sell) if trade_price <= order.price => true,
            _ => false,
        }
    }

    fn log_close(
        &mut self,
        position: &Position,
        exit_time: u64,
        exit_price: Decimal,
        reason: ExitReason,
        exit_from_cluster: bool,
    ) {
        let direction = position.direction;
        let gross_ticks = ((exit_price - position.entry_price) / self.config.tick_size)
            * Self::direction_factor(direction);

        let entry_fee = self.exchange_fee(position.entry_price, self.config.fee_rate_maker);
        let exit_fee = self.exchange_fee(exit_price, self.config.fee_rate_maker);
        let total_fee = entry_fee + exit_fee;

        let net_ticks = gross_ticks - (total_fee / self.config.tick_size);
        let gross_ret = ((exit_price - position.entry_price) / position.entry_price)
            * Self::direction_factor(direction);
        let net_ret = gross_ret - (total_fee / position.entry_price);

        let hold_ms = exit_time.saturating_sub(position.entry_time);

        let record = TradeLog {
            entry_time: position.entry_time,
            exit_time,
            direction,
            entry_price: position.entry_price,
            exit_price,
            gross_ticks,
            net_ticks,
            gross_ret,
            net_ret,
            reason,
            exit_liquidity: "maker",
            tp_plain: position.tp_plain,
            exit_from_cluster,
            entry_fee,
            exit_fee,
            total_fee,
            hold_ms,
        };

        if let Err(err) = self.writer.serialize(&record) {
            warn!(%err, "failed to write trade log");
        }
        if let Err(err) = self.writer.flush() {
            warn!(%err, "failed to flush trade log");
        }

        self.trades.push(record);
        info!(exit_time, %exit_price, ?direction, ?reason, "position closed");
    }

    fn finalize(&mut self) {
        let state_snapshot = std::mem::replace(&mut self.state, TradeState::Flat);
        match state_snapshot {
            TradeState::Flat => {}
            TradeState::WaitingEntry(_) => {}
            TradeState::InPosition { position, .. } => {
                let exit_price = self
                    .last_trade_price
                    .or_else(|| match (self.last_best_bid, self.last_best_ask) {
                        (Some(bid), Some(ask)) => Some((bid.price + ask.price) / dec!(2)),
                        (Some(bid), None) => Some(bid.price),
                        (None, Some(ask)) => Some(ask.price),
                        _ => None,
                    })
                    .unwrap_or(position.entry_price);

                let ts = self.last_ts.unwrap_or(position.entry_time);
                self.log_close(&position, ts, exit_price, ExitReason::TimeStopLimit, false);
            }
        }
    }

    fn exchange_fee(&self, price: Decimal, rate: Decimal) -> Decimal {
        (price * rate * self.config.order_size) + self.config.broker_fee_abs
    }
}

#[derive(Debug, Clone, Copy)]
struct ClusterSideInfo {
    max_price: Decimal,
    max_size: Decimal,
    max_depth: usize,
    best_price: Decimal,
    best_size: Decimal,
}

#[derive(Debug, Clone, Copy)]
struct ClusterInfo {
    bid: Option<ClusterSideInfo>,
    ask: Option<ClusterSideInfo>,
}

fn compute_cluster_info(book: &OrderBook, depth: usize) -> ClusterInfo {
    let bid = compute_side_info(book.bids().levels(), depth);
    let ask = compute_side_info(book.asks().levels(), depth);
    ClusterInfo { bid, ask }
}

fn compute_side_info(
    levels: &[barter_data::books::Level],
    depth: usize,
) -> Option<ClusterSideInfo> {
    let best = levels.first()?;
    let mut max = Level {
        price: best.price,
        amount: best.amount,
    };
    let mut max_depth = 0;

    for (idx, level) in levels.iter().take(depth).enumerate() {
        if level.amount > max.amount {
            max = Level {
                price: level.price,
                amount: level.amount,
            };
            max_depth = idx;
        }
    }

    Some(ClusterSideInfo {
        max_price: max.price,
        max_size: max.amount,
        max_depth,
        best_price: best.price,
        best_size: best.amount,
    })
}

fn quantile(data: &[f64], q: f64) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    let mut sorted = data.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
    let idx = ((sorted.len() - 1) as f64 * q).round() as usize;
    sorted[idx]
}

fn quantile_if_ready(data: &[f64], q: f64, min_len: usize) -> Option<f64> {
    if data.len() < min_len {
        None
    } else {
        Some(quantile(data, q))
    }
}

fn price_diff_in_ticks(a: Decimal, b: Decimal, tick: Decimal) -> Decimal {
    let diff = if a > b { a - b } else { b - a };
    diff / tick
}

fn load_app_config(path: Option<String>) -> Result<AppConfig, Box<dyn Error>> {
    let path = path.unwrap_or_else(|| DEFAULT_APP_CONFIG.to_string());

    match File::open(Path::new(&path)) {
        Ok(file) => Ok(serde_json::from_reader(file)?),
        Err(err) => {
            warn!(
                ?path,
                ?err,
                "failed to load app config file, falling back to defaults"
            );
            Ok(AppConfig::default())
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    init_logging();

    let config_path = std::env::args().nth(1);
    let app_config = load_app_config(config_path)?;
    info!(?app_config, "starting live paper scalper");

    let system_config: barter::system::config::SystemConfig = {
        let file = File::open(Path::new(&app_config.system_config_path))?;
        serde_json::from_reader(file)?
    };

    let instruments = IndexedInstruments::new(system_config.instruments);
    let mut streams = init_indexed_multi_exchange_market_stream(
        &instruments,
        &[SubKind::OrderBooksL2, SubKind::PublicTrades],
    )
    .await?;

    let writer = csv::Writer::from_path(Path::new(&app_config.output_csv))?;
    let mut trader = LivePaperTrader::new(app_config.strategy, app_config.min_history, writer);

    let mut books: HashMap<InstrumentIndex, OrderBook> = HashMap::new();
    let deadline = Instant::now() + Duration::from_secs(app_config.runtime_secs);

    while let Some(event) = streams.next().await {
        if Instant::now() >= deadline {
            info!("runtime budget elapsed, finalizing");
            break;
        }

        match event {
            MarketStreamEvent::Item(evt) => match evt.kind {
                DataKind::OrderBook(orderbook) => {
                    let book = books.entry(evt.instrument).or_default();
                    book.update(&orderbook);
                    let ts = evt.time_exchange.timestamp_millis() as u64;
                    trader.on_update(MarketUpdate::OrderBook {
                        ts,
                        book: book.clone(),
                    });
                }
                DataKind::Trade(trade) => {
                    let ts = evt.time_exchange.timestamp_millis() as u64;
                    let price = Decimal::from_f64(trade.price).unwrap_or_default();
                    trader.on_update(MarketUpdate::Trade {
                        ts,
                        side: trade.side,
                        price,
                        size: Decimal::from_f64(trade.amount).unwrap_or_default(),
                    });
                }
                _ => {}
            },
            MarketStreamEvent::Reconnecting(exchange) => {
                warn!(?exchange, "market stream reconnecting")
            }
        }
    }

    trader.finalize();

    info!(count = trader.trades.len(), "exiting live paper scalper");
    Ok(())
}