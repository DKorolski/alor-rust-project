use std::{collections::HashMap, error::Error, fs::OpenOptions, path::PathBuf};

use barter::logging::init_logging;
use barter_data::{
    books::OrderBook,
    event::{DataKind, MarketEvent},
    streams::{
        builder::dynamic::indexed::init_indexed_multi_exchange_market_stream,
        reconnect::Event as StreamEvent,
    },
    subscription::SubKind,
};
use barter_instrument::{
    Underlying,
    asset::name::AssetNameExchange,
    exchange::ExchangeId,
    index::IndexedInstruments,
    instrument::InstrumentIndex,
    instrument::{
        kind::{InstrumentKind, perpetual::PerpetualContract},
        quote::InstrumentQuoteAsset,
    },
};
use chrono::{DateTime, Utc};
use csv::Writer;
use futures::StreamExt;
use rust_decimal::prelude::ToPrimitive;
use rust_decimal_macros::dec;
use tracing::{info, warn};

use barter::system::config::InstrumentConfig;

/// Configuration parameters mirroring the reference Python version.
#[derive(Debug, Clone)]
struct StrategyConfig {
    symbol: String,
    depth: usize,
    tick_size: f64,
    order_size: f64,
    fee_rate_maker: f64,
    fee_rate_taker: f64,
    broker_fee_abs: f64,
    adverse_ticks: f64,
    tp_ticks: f64,
    entry_cluster_q: f64,
    max_cluster_depth_entry: usize,
    exit_cluster_q: f64,
    max_cluster_depth_exit: usize,
    min_history_for_quantiles: usize,
    csv_path: PathBuf,
    exit_cluster_max_diff_ticks: f64,
}

impl Default for StrategyConfig {
    fn default() -> Self {
        Self {
            symbol: "BTCUSDT".to_string(),
            depth: 200,
            tick_size: 0.1,
            order_size: 1.0,
            fee_rate_maker: 0.0,
            fee_rate_taker: 0.000066,
            broker_fee_abs: 1.0,
            adverse_ticks: 50.0,
            tp_ticks: 200.0,
            entry_cluster_q: 0.895,
            max_cluster_depth_entry: 12,
            exit_cluster_q: 0.05,
            max_cluster_depth_exit: 12,
            min_history_for_quantiles: 50,
            csv_path: PathBuf::from("barter/examples/data/scalping_live_v10.csv"),
            exit_cluster_max_diff_ticks: 197.0,
        }
    }
}

#[derive(Debug, Clone)]
struct TradeResult {
    entry_time: DateTime<Utc>,
    exit_time: DateTime<Utc>,
    direction: &'static str,
    side: i8,
    entry_price: f64,
    exit_price: f64,
    gross_ticks: f64,
    net_ticks: f64,
    gross_ret: f64,
    net_ret: f64,
    reason: String,
    exit_liquidity: &'static str,
    tp_plain: f64,
    exit_from_cluster: bool,
    entry_fee: f64,
    exit_fee: f64,
    total_fee: f64,
    waited_ms_for_fill: i64,
    hold_ms: i64,
}

#[derive(Debug, Default)]
struct QuantileStats {
    bid_cluster_hist: Vec<f64>,
    ask_cluster_hist: Vec<f64>,
    bid_entry_thr: Option<f64>,
    ask_entry_thr: Option<f64>,
    bid_exit_thr: Option<f64>,
    ask_exit_thr: Option<f64>,
}

impl QuantileStats {
    fn update(&mut self, cfg: &StrategyConfig, cbv: f64, cav: f64) {
        if cbv > 0.0 {
            self.bid_cluster_hist.push(cbv);
        }
        if cav > 0.0 {
            self.ask_cluster_hist.push(cav);
        }

        if self.bid_cluster_hist.len() >= cfg.min_history_for_quantiles
            && self.ask_cluster_hist.len() >= cfg.min_history_for_quantiles
        {
            self.bid_entry_thr = quantile(&self.bid_cluster_hist, cfg.entry_cluster_q);
            self.ask_entry_thr = quantile(&self.ask_cluster_hist, cfg.entry_cluster_q);
            self.bid_exit_thr = quantile(&self.bid_cluster_hist, cfg.exit_cluster_q);
            self.ask_exit_thr = quantile(&self.ask_cluster_hist, cfg.exit_cluster_q);
        }
    }

    fn ready(&self) -> bool {
        self.bid_entry_thr.is_some()
            && self.ask_entry_thr.is_some()
            && self.bid_exit_thr.is_some()
            && self.ask_exit_thr.is_some()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum TradeState {
    Flat,
    WaitingEntry,
    InPosition,
}

#[derive(Debug)]
struct ScalpingEngine {
    cfg: StrategyConfig,
    quantiles: QuantileStats,
    state: TradeState,
    side: i8,
    order_price: Option<f64>,
    order_ts: Option<i64>,
    queue_ahead: f64,
    entry_order_ts: Option<i64>,
    entry_price: Option<f64>,
    entry_ts: Option<i64>,
    entry_time: Option<DateTime<Utc>>,
    tp_plain: Option<f64>,
    exit_order_price: Option<f64>,
    exit_order_ts: Option<i64>,
    exit_queue_ahead: f64,
    exit_reason_target: Option<String>,
    favorable_price: Option<f64>,
    last_trade_price: Option<f64>,
    last_mid: Option<f64>,
    last_time: Option<DateTime<Utc>>,
    writer: Writer<std::fs::File>,
}

impl ScalpingEngine {
    fn new(cfg: StrategyConfig) -> Result<Self, Box<dyn Error>> {
        let writer = init_csv(&cfg.csv_path)?;
        Ok(Self {
            cfg,
            quantiles: QuantileStats::default(),
            state: TradeState::Flat,
            side: 0,
            order_price: None,
            order_ts: None,
            queue_ahead: 0.0,
            entry_order_ts: None,
            entry_price: None,
            entry_ts: None,
            entry_time: None,
            tp_plain: None,
            exit_order_price: None,
            exit_order_ts: None,
            exit_queue_ahead: 0.0,
            exit_reason_target: None,
            favorable_price: None,
            last_trade_price: None,
            last_mid: None,
            last_time: None,
            writer,
        })
    }

    fn on_orderbook(&mut self, ts: i64, time: DateTime<Utc>, book: &OrderBook) {
        let (bbp, bbv, bap, bav) = match (book.bids().best(), book.asks().best()) {
            (Some(bid), Some(ask)) => (
                bid.price.to_f64().unwrap_or_default(),
                bid.amount.to_f64().unwrap_or_default(),
                ask.price.to_f64().unwrap_or_default(),
                ask.amount.to_f64().unwrap_or_default(),
            ),
            _ => return,
        };

        let (cbp, cbv, cbd) = max_cluster(book.bids().levels(), self.cfg.max_cluster_depth_entry);
        let (cap, cav, cad) = max_cluster(book.asks().levels(), self.cfg.max_cluster_depth_entry);

        self.quantiles.update(&self.cfg, cbv, cav);

        self.last_mid = Some((bbp + bap) / 2.0);
        self.last_time = Some(time);

        if self.state == TradeState::InPosition {
            if self.side == 1 {
                self.favorable_price = Some(
                    self.favorable_price
                        .unwrap_or(self.entry_price.unwrap())
                        .max(bbp),
                );
            } else if self.side == -1 {
                self.favorable_price = Some(
                    self.favorable_price
                        .unwrap_or(self.entry_price.unwrap())
                        .min(bap),
                );
            }
        }

        if self.state == TradeState::WaitingEntry {
            if let Some(order_ts) = self.order_ts {
                if ts - order_ts >= 800 {
                    self.reset_waiting();
                }
            }
        }

        if self.state == TradeState::InPosition {
            if let (Some(exit_ts), Some(_)) = (self.exit_order_ts, self.exit_order_price) {
                if ts - exit_ts >= 1_500 {
                    self.exit_order_price = None;
                    self.exit_order_ts = None;
                    self.exit_queue_ahead = 0.0;
                    self.exit_reason_target = None;
                }
            }
        }

        if self.state == TradeState::InPosition
            && self.exit_order_price.is_none()
            && self.tp_plain.is_some()
            && self.quantiles.ready()
        {
            match self.side {
                1 => {
                    let is_big_ask = cav >= self.quantiles.ask_exit_thr.unwrap()
                        && cad
                            .map(|d| d <= self.cfg.max_cluster_depth_exit)
                            .unwrap_or(false)
                        && cap.is_some();
                    if is_big_ask {
                        if let Some(cap) = cap {
                            let candidate = cap - self.cfg.tick_size;
                            if (candidate - self.tp_plain.unwrap()).abs()
                                <= self.cfg.exit_cluster_max_diff_ticks * self.cfg.tick_size
                            {
                                self.exit_order_price = Some(candidate);
                                self.exit_order_ts = Some(ts);
                                self.exit_reason_target = Some("cluster_exit".to_string());
                                self.exit_queue_ahead = 0.0;
                            }
                        }
                    }
                }
                -1 => {
                    let is_big_bid = cbv >= self.quantiles.bid_exit_thr.unwrap()
                        && cbd
                            .map(|d| d <= self.cfg.max_cluster_depth_exit)
                            .unwrap_or(false)
                        && cbp.is_some();
                    if is_big_bid {
                        if let Some(cbp) = cbp {
                            let candidate = cbp + self.cfg.tick_size;
                            if (candidate - self.tp_plain.unwrap()).abs()
                                <= self.cfg.exit_cluster_max_diff_ticks * self.cfg.tick_size
                            {
                                self.exit_order_price = Some(candidate);
                                self.exit_order_ts = Some(ts);
                                self.exit_reason_target = Some("cluster_exit".to_string());
                                self.exit_queue_ahead = 0.0;
                            }
                        }
                    }
                }
                _ => {}
            }
        }

        if self.state == TradeState::InPosition
            && self.exit_order_price.is_none()
            && self.entry_price.is_some()
            && self.favorable_price.is_some()
        {
            if self.side == 1 {
                let adverse_ticks = (self.favorable_price.unwrap() - bbp) / self.cfg.tick_size;
                if adverse_ticks >= self.cfg.adverse_ticks {
                    self.exit_order_price = Some(bap);
                    self.exit_order_ts = Some(ts);
                    self.exit_queue_ahead = (bav - self.cfg.order_size).max(0.0);
                    self.exit_reason_target = Some("adverse_exit".to_string());
                }
            } else if self.side == -1 {
                let adverse_ticks = (bap - self.favorable_price.unwrap()) / self.cfg.tick_size;
                if adverse_ticks >= self.cfg.adverse_ticks {
                    self.exit_order_price = Some(bbp);
                    self.exit_order_ts = Some(ts);
                    self.exit_queue_ahead = (bbv - self.cfg.order_size).max(0.0);
                    self.exit_reason_target = Some("adverse_exit".to_string());
                }
            }
        }

        if self.state == TradeState::Flat && self.quantiles.ready() {
            let is_bid_entry = cbv >= self.quantiles.bid_entry_thr.unwrap()
                && cbd
                    .map(|d| d <= self.cfg.max_cluster_depth_entry)
                    .unwrap_or(false)
                && cbv > cav
                && cbp.is_some();
            let is_ask_entry = cav >= self.quantiles.ask_entry_thr.unwrap()
                && cad
                    .map(|d| d <= self.cfg.max_cluster_depth_entry)
                    .unwrap_or(false)
                && cav > cbv
                && cap.is_some();

            if is_bid_entry {
                self.state = TradeState::WaitingEntry;
                self.side = 1;
                self.order_price = cbp.map(|p| p - self.cfg.tick_size);
                self.order_ts = Some(ts);
                self.entry_order_ts = Some(ts);
                self.queue_ahead = (bbv - self.cfg.order_size).max(0.0);
            } else if is_ask_entry {
                self.state = TradeState::WaitingEntry;
                self.side = -1;
                self.order_price = cap.map(|p| p + self.cfg.tick_size);
                self.order_ts = Some(ts);
                self.entry_order_ts = Some(ts);
                self.queue_ahead = (bav - self.cfg.order_size).max(0.0);
            }
        }
    }

    fn on_trade(&mut self, ts: i64, time: DateTime<Utc>, price: f64, size: f64) {
        self.last_trade_price = Some(price);
        self.last_time = Some(time);

        if self.state == TradeState::WaitingEntry {
            if let Some(order_price) = self.order_price {
                if (self.side == 1 && price <= order_price + f64::EPSILON)
                    || (self.side == -1 && price >= order_price - f64::EPSILON)
                {
                    self.queue_ahead -= size;
                }

                if self.queue_ahead <= 0.0 {
                    info!(
                        "entry filled {} at {:.4}",
                        if self.side == 1 { "long" } else { "short" },
                        order_price
                    );
                    self.state = TradeState::InPosition;
                    self.entry_price = Some(order_price);
                    self.entry_ts = Some(ts);
                    self.entry_time = Some(time);
                    self.tp_plain = Some(if self.side == 1 {
                        order_price + self.cfg.tp_ticks * self.cfg.tick_size
                    } else {
                        order_price - self.cfg.tp_ticks * self.cfg.tick_size
                    });
                    self.favorable_price = Some(order_price);
                    self.order_price = None;
                    self.order_ts = None;
                    self.queue_ahead = 0.0;
                    self.exit_order_price = None;
                    self.exit_order_ts = None;
                    self.exit_reason_target = None;
                }
            }
        }

        if self.state == TradeState::InPosition && self.exit_order_price.is_some() {
            let exit_price = self.exit_order_price.unwrap();
            if (self.side == 1 && price >= exit_price - f64::EPSILON)
                || (self.side == -1 && price <= exit_price + f64::EPSILON)
            {
                self.exit_queue_ahead -= size;
            }

            if self.exit_queue_ahead <= 0.0 {
                self.close_position(time);
            }
        }
    }

    fn close(&mut self) {
        if self.state == TradeState::InPosition {
            let price = self
                .last_trade_price
                .or(self.last_mid)
                .or(self.entry_price)
                .unwrap_or(0.0);
            let time = self.last_time.unwrap_or_else(Utc::now);
            self.log_trade(
                price,
                time,
                self.exit_reason_target
                    .clone()
                    .unwrap_or_else(|| "eod_force".into()),
            );
        }
    }

    fn close_position(&mut self, time: DateTime<Utc>) {
        if let Some(exit_price) = self.exit_order_price {
            let reason = self
                .exit_reason_target
                .clone()
                .unwrap_or_else(|| "limit_exit".to_string());
            self.log_trade(exit_price, time, reason);
        }
    }

    fn log_trade(&mut self, exit_price: f64, exit_time: DateTime<Utc>, reason: String) {
        if let (Some(entry_price), Some(entry_time), Some(entry_ts)) =
            (self.entry_price, self.entry_time, self.entry_ts)
        {
            let side = self.side;
            let pnl_px = side as f64 * (exit_price - entry_price) * self.cfg.order_size;
            let entry_fee = self.cfg.fee_rate_maker * entry_price * self.cfg.order_size
                + self.cfg.broker_fee_abs;
            let exit_fee = self.cfg.fee_rate_maker * exit_price * self.cfg.order_size
                + self.cfg.broker_fee_abs;
            let total_fee = entry_fee + exit_fee;
            let notional_entry = entry_price * self.cfg.order_size;
            let gross_ret = pnl_px / notional_entry;
            let net_ret = (pnl_px - total_fee) / notional_entry;
            let gross_ticks = side as f64 * (exit_price - entry_price) / self.cfg.tick_size;
            let rel_tick = self.cfg.tick_size / entry_price;
            let net_ticks = net_ret / rel_tick;
            let waited_ms = self.entry_order_ts.map(|ts| entry_ts - ts).unwrap_or(0);
            let hold_ms = exit_time.timestamp_millis() - entry_time.timestamp_millis();

            let trade = TradeResult {
                entry_time,
                exit_time,
                direction: if side == 1 { "long" } else { "short" },
                side,
                entry_price,
                exit_price,
                gross_ticks,
                net_ticks,
                gross_ret,
                net_ret,
                reason: reason.clone(),
                exit_liquidity: "maker",
                tp_plain: self.tp_plain.unwrap_or(exit_price),
                exit_from_cluster: reason == "cluster_exit",
                entry_fee,
                exit_fee,
                total_fee,
                waited_ms_for_fill: waited_ms,
                hold_ms,
            };

            self.writer
                .write_record([
                    trade.entry_time.to_rfc3339(),
                    trade.exit_time.to_rfc3339(),
                    trade.direction.to_string(),
                    trade.side.to_string(),
                    format!("{:.4}", trade.entry_price),
                    format!("{:.4}", trade.exit_price),
                    format!("{:.4}", trade.gross_ticks),
                    format!("{:.4}", trade.net_ticks),
                    format!("{:.8}", trade.gross_ret),
                    format!("{:.8}", trade.net_ret),
                    trade.reason.clone(),
                    trade.exit_liquidity.to_string(),
                    format!("{:.4}", trade.tp_plain),
                    if trade.exit_from_cluster { "1" } else { "0" }.to_string(),
                    format!("{:.4}", trade.entry_fee),
                    format!("{:.4}", trade.exit_fee),
                    format!("{:.4}", trade.total_fee),
                    trade.waited_ms_for_fill.to_string(),
                    trade.hold_ms.to_string(),
                ])
                .ok();
            let _ = self.writer.flush();

            self.reset();
        }
    }

    fn reset(&mut self) {
        self.state = TradeState::Flat;
        self.side = 0;
        self.order_price = None;
        self.order_ts = None;
        self.queue_ahead = 0.0;
        self.entry_order_ts = None;
        self.entry_price = None;
        self.entry_ts = None;
        self.entry_time = None;
        self.tp_plain = None;
        self.exit_order_price = None;
        self.exit_order_ts = None;
        self.exit_queue_ahead = 0.0;
        self.exit_reason_target = None;
        self.favorable_price = None;
    }

    fn reset_waiting(&mut self) {
        self.state = TradeState::Flat;
        self.side = 0;
        self.order_price = None;
        self.order_ts = None;
        self.queue_ahead = 0.0;
        self.entry_order_ts = None;
    }
}

fn quantile(data: &[f64], q: f64) -> Option<f64> {
    if data.is_empty() {
        return None;
    }
    let mut v = data.to_vec();
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let idx = ((v.len() - 1) as f64 * q).round() as usize;
    v.get(idx).copied()
}

fn max_cluster(
    levels: &[barter_data::books::Level],
    max_depth: usize,
) -> (Option<f64>, f64, Option<usize>) {
    let mut price = None;
    let mut size = 0.0;
    let mut depth = None;

    for (idx, level) in levels.iter().take(max_depth).enumerate() {
        let level_size = level.amount.to_f64().unwrap_or_default();
        if level_size > size {
            price = level.price.to_f64();
            size = level_size;
            depth = Some(idx);
        }
    }

    (price, size, depth)
}

fn init_csv(path: &PathBuf) -> Result<Writer<std::fs::File>, Box<dyn Error>> {
    let file = OpenOptions::new().create(true).append(true).open(path)?;
    let is_empty = path.metadata().map(|m| m.len() == 0).unwrap_or(true);
    let mut writer = Writer::from_writer(file);
    if is_empty {
        writer.write_record([
            "entry_time",
            "exit_time",
            "direction",
            "side",
            "entry_price",
            "exit_price",
            "gross_ticks",
            "net_ticks",
            "gross_ret",
            "net_ret",
            "reason",
            "exit_liquidity",
            "tp_plain",
            "exit_from_cluster",
            "entry_fee",
            "exit_fee",
            "total_fee",
            "waited_ms_for_fill",
            "hold_ms",
        ])?;
    }
    Ok(writer)
}

fn instrument_config(symbol: &str) -> InstrumentConfig {
    InstrumentConfig {
        exchange: ExchangeId::BybitPerpetualsUsd,
        name_exchange: symbol.into(),
        underlying: Underlying::new("btc", "usdt"),
        quote: InstrumentQuoteAsset::UnderlyingQuote,
        kind: InstrumentKind::Perpetual(PerpetualContract {
            contract_size: dec!(1),
            settlement_asset: AssetNameExchange::from("usdt"),
        }),
        spec: None,
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    init_logging();

    let symbols = vec!["BTCUSDT"];
    let instrument_cfgs: Vec<_> = symbols.iter().map(|s| instrument_config(s)).collect();
    let instruments = IndexedInstruments::new(instrument_cfgs.clone());

    let mut engines: HashMap<InstrumentIndex, ScalpingEngine> = HashMap::new();
    let mut books: HashMap<InstrumentIndex, OrderBook> = HashMap::new();
    for keyed in instruments.instruments() {
        let symbol = keyed.value.name_exchange.to_string();
        let mut cfg = StrategyConfig::default();
        cfg.symbol = symbol.clone();
        cfg.csv_path = PathBuf::from(format!("trades_live_{}.csv", symbol.to_lowercase()));
        engines.insert(keyed.key, ScalpingEngine::new(cfg)?);
    }

    let mut market_stream = init_indexed_multi_exchange_market_stream(
        &instruments,
        &[SubKind::OrderBooksL2, SubKind::PublicTrades],
    )
    .await?;

    info!("starting live scalping stream");
    let shutdown = tokio::signal::ctrl_c();
    tokio::pin!(shutdown);

    loop {
        tokio::select! {
            _ = shutdown.as_mut() => {
                info!("shutdown requested");
                break;
            }
            Some(event) = market_stream.next() => {
                match event {
                    StreamEvent::Item(evt) => handle_event(evt, &mut engines, &mut books),
                    StreamEvent::Reconnecting(exch) => warn!(%exch, "market stream reconnecting"),
                }
            }
            else => break,
        }
    }

    for engine in engines.values_mut() {
        engine.close();
    }

    Ok(())
}

fn handle_event(
    event: MarketEvent<InstrumentIndex, DataKind>,
    engines: &mut HashMap<InstrumentIndex, ScalpingEngine>,
    books: &mut HashMap<InstrumentIndex, OrderBook>,
) {
    let ts = event.time_exchange.timestamp_millis();
    if let Some(engine) = engines.get_mut(&event.instrument) {
        match event.kind {
            DataKind::OrderBook(ob_event) => {
                let book = books.entry(event.instrument).or_default();
                book.update(&ob_event);
                engine.on_orderbook(ts, event.time_exchange, book);
            }
            DataKind::Trade(trade) => {
                engine.on_trade(ts, event.time_exchange, trade.price, trade.amount);
            }
            _ => {}
        }
    }
}